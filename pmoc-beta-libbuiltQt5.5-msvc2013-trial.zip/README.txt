PMOC TRIAL VERSION
*100 launches limited
*30 days limited
:(

place generated plugins in <runtime directory>\Plugins
and custom qml files in <runtime directory>\qml\<plugin_name>\<classpath>.qml
see https://github.com/mp3butcher/osg4noob for osg sample instrumentation

In order to edit qml at runtime (using qtcreator) setup environment variable PMOC_NOCACHE (to disable qml caching)

more infos:
http://osg4noob.olympe.info
or mailto:julienvalentin51@gmail.com

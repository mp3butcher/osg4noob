#include <osg/StateSet>
#include <iostream>
#include <sstream>
//includes
#include <customCode/osg/StateSet_pmoc.hpp>
#include <customCode/osg/Texture2D_pmoc.hpp>
#include <customCode/osg/Texture1D_pmoc.hpp>
#include <customCode/osg/Texture3D_pmoc.hpp>
#include <customCode/osg/Texture3D_pmoc.hpp>
#include <customCode/osg/Uniform_pmoc.hpp>
#include <customCode/osg/StateAttribute_pmoc.hpp>

#include <MetaQQuickLibraryRegistry.h>
using namespace std;

using namespace pmoc;

       void osg::QMLStateSet::setAttribute(osg::QReflect_StateAttribute * p){
      _model->setAttributeAndModes(p->_model,StateAttribute::ON);
      }
     void osg::QMLStateSet::pmoc_reverse_setAttribute(osg::QReflect_StateAttribute *p){
    _model->setAttributeAndModes(p->_model,StateAttribute::OFF);
    if(p->_model->asTexture()){

int tu=0;
        for( osg::StateSet::TextureAttributeList::const_iterator it= _model->getTextureAttributeList().begin();
                it!=_model->getTextureAttributeList().end() ; it++)
        {

            for(osg::StateSet::AttributeList::const_iterator it2=(*it).begin(); it2!=(*it).end(); it2++)
            {
                osg::StateAttribute * s=(*it2).second.first;
                if(s==p->_model)tu=(*it2).second.second;
            }
        }
    _model->removeTextureAttribute(tu,p->_model);

    }

    else
     _model->removeAttribute(p->_model );
    }
         void osg::QMLStateSet::addUniform(osg::QReflect_Uniform * p){
      _model->addUniform(p->_model, StateAttribute::ON);
      }
     void osg::QMLStateSet::pmoc_reverse_addUniform(osg::QReflect_Uniform *p){
    _model->removeUniform(p->_model);
    }
///For Textures

int osg::QMLStateSet::QMLStateSet::getTextureUnit(QQModel*mod)
{
    osg::QMLTexture2D * tex= dynamic_cast<osg::QMLTexture2D*>(mod);
    if(tex)
    {

        cout<<"Modelist"<<endl;
        for(osg::StateSet::TextureModeList::iterator tuit=_model->getTextureModeList().begin(); tuit!=_model->getTextureModeList().end(); tuit++)
        {
            for(osg::StateSet::ModeList::iterator tuit2=(*tuit).begin(); tuit2!=(*tuit).end(); tuit2++)
            {

                cout<<(*tuit2).second<<endl;
            }
        }

        for( osg::StateSet::TextureAttributeList::const_iterator it= _model->getTextureAttributeList().begin();
                it!=_model->getTextureAttributeList().end() ; it++)
        {

            for(osg::StateSet::AttributeList::const_iterator it2=(*it).begin(); it2!=(*it).end(); it2++)
            {
                osg::StateAttribute * s=(*it2).second.first;
                if(s==tex->_model)return (*it2).second.second;
            }
        }

    }
}
osg::QMLStateSet::QMLStateSet(pmoc::Instance *i,QObject* parent):QReflect_StateSet(i,parent)
{
//custom initializations

    qmlRegisterType<pmoc::StateAttribListModel>("StateAttribListModel",1,0,"StateAttribListModel");
    textype.push_back(osg::StateAttribute::TEXENV);
    textype.push_back(osg::StateAttribute::TEXGEN);
    textype.push_back(osg::StateAttribute::TEXMAT);
    textype.push_back(osg::StateAttribute::TEXTURE);
    _currentattrib=0;
updateModel();
}
QQuickItem* osg::QMLStateSet::connect2View(QQuickItem*i)
{
    this->_view=QReflect_StateSet::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
    ///CustomiZE here

    connect(_view,SIGNAL(attributeselected(int)),this,SLOT(popStateAttribute(int)));

    connect(_view,SIGNAL(texattributeselected(int)),this,SLOT(popTextureStateAttribute(int)));
    connect(_view,SIGNAL(uniformselected(int)),this,SLOT(popUniform(int)));

///HACK THE COMBOBOX
    QQuickItem *hack=_view->findChild<QQuickItem*>("renderingHintBox2Hack");
    if(hack) hack->setProperty("currentIndex",  getRenderingHint());


    return this->_view;
}

void  osg::QMLStateSet::updateModel()
{
    _uniformslist.resetListViewModel();
    for( osg::StateSet::UniformList::const_iterator it= _model->getUniformList().begin();
            it!=_model->getUniformList().end() ; it++)
    {
        cerr<<osg::Uniform::getTypename((*it).second.first->getType())<<endl;
        if((*it).second.first.valid())
        {
            osg::Uniform * s=(*it).second.first.get();

        PMOCSAFEADDOBJECT( *s,inst);
            QString classname=QString(inst.model->id().c_str());
            _uniformslist.addStateAttrib( StateAttribObject(classname ,QString(s->getName().c_str())));
        }
    }
    emit uniformsListChanged(&_uniformslist);
    _attlist.resetListViewModel();
    for( osg::StateSet::AttributeList::const_iterator it= _model->getAttributeList().begin();
            it!=_model->getAttributeList().end() ; it++)
    {
        if((*it).second.first.valid())
        {
            osg::StateAttribute * s=(*it).second.first.get();

        PMOCSAFEADDOBJECT( *s,inst);
            QString classname=QString(inst.model->id().c_str());
            _attlist.addStateAttrib( StateAttribObject(classname ,QString(s->getName().c_str())));
        }
    }



    _texattlist.resetListViewModel();
    /*    for( osg::StateSet::TextureAttributeList::const_iterator it= _model->getTextureAttributeList().begin();
                it!=_model->getTextureAttributeList().end() ; it++)
        {


            for(osg::StateSet::AttributeList::const_iterator it2=(*it).begin(); it2!=(*it).end(); it2++)
            {
                osg::StateAttribute * s=(*it2).second.first;
                cerr<<"AttributeList"<<(*it2).second.second<<endl;
                cerr<<"AttributeList"<<(*it2).first.second<<endl;
                cerr<<"AttributeList"<<(*it2).first.first<<endl;
                Instance inst =PMOCADDOBJECT(*s);
                QString classname=QString(inst.model->id().c_str());
                cerr<<classname.toStdString()<<endl;
                _texattlist.addStateAttrib( StateAttribObject(classname ,"yellow"));
            }
        }*/


    osg::StateAttribute* temp;
    for(    vector<osg::StateAttribute::Type>::iterator it= textype.begin(); it!=textype.end(); it++)
    {
        for(int i=0; i<100; i++)
        {
            temp=_model->getTextureAttribute(i,*it);
            if(temp)
            {
                stringstream ss;
                ss<<i;
        PMOCSAFEADDOBJECT( *temp,inst);
                QString classname=QString((ss.str()+inst.model->id()).c_str());
                cerr<<classname.toStdString()<<endl;
                _texattlist.addStateAttrib( StateAttribObject(classname ,QString(temp->getName().c_str())));
            }

        }

    }

    emit texstateAttribsChanged(&_texattlist);
    emit stateAttribsChanged(&_attlist);
    emit uniformsListChanged(&_uniformslist);
}

void  osg::QMLStateSet::popUniform(int i)
{
    ///HACK OSG: in case of UNDEFINED type Shader recently added
    //remove all shader and readd them
    vector<osg::ref_ptr<osg::Uniform> > temp;
    for( osg::StateSet::UniformList::const_iterator it= _model->getUniformList().begin();
            it!=_model->getUniformList().end() ; it++)
        temp.push_back((*it).second.first);

    for(vector< osg::ref_ptr<osg::Uniform> >::iterator it=temp.begin(); it!=temp.end(); it++)
        _model->removeUniform(*it);


    for(vector< osg::ref_ptr<osg::Uniform> >::iterator it=temp.begin(); it!=temp.end(); it++)
        _model->addUniform(*it);

    //if(_currentattrib)delete _currentattrib;
    _currentattrib=0;//_currentattrib->setParentItem(0);
    osg::StateSet::UniformList::const_iterator it=_model->getUniformList().begin();
    int cpt=0;

    for(  ;   it!=_model->getUniformList().end()&&cpt<i ; it++)
    {
        if((*it).second.first.valid())
        {
            cerr<<osg::Uniform::getTypename((*it).second.first->getType())<<endl;
            cpt++;
        }
    }
    if(it!=_model->getUniformList().end() )
    {


        osg::Uniform * s=(*it).second.first;
        PMOCSAFEADDOBJECT( *s,inst);
        QQUICKCOMPONENTWITHNAME(inst,_view,"Uniform");


    }
}
void  osg::QMLStateSet::popStateAttribute(int i)
{
    //if(_currentattrib)delete _currentattrib;
    _currentattrib=0;//_currentattrib->setParentItem(0);
    osg::StateSet::AttributeList::const_iterator its= _model->getAttributeList().begin(); ;
    int cpt=0;
    for( its= _model->getAttributeList().begin();            its!=_model->getAttributeList().end() &&cpt!=i; its++)cpt++;

    if (  its!=_model->getAttributeList().end())
    {
        //reached
        osg::StateAttribute * s=(*its).second.first;
        PMOCSAFEADDOBJECT( *s,inst);
        _currentattrib=QQUICKCOMPONENTWITHNAME(inst,_view,"Attribute");
    }

}

void  osg::QMLStateSet::popTextureStateAttribute(int i)
{
    //if(_currentattrib)delete _currentattrib;
    _currentattrib=0;//_currentattrib->setParentItem(0);
    int cpt=0;
    {

        osg::StateAttribute* temp=0;
        for(    vector<osg::StateAttribute::Type>::iterator it= textype.begin(); it!=textype.end()&&cpt<=i; it++)
        {
            for(int xi=0; xi<100&&cpt<=i; xi++)
            {
                temp=_model->getTextureAttribute(xi,*it);
                if(temp)cpt++;


            }
        }
        if (temp)
        {
        PMOCSAFEADDOBJECT( *temp,inst);
            QString classname=QString(inst.model->id().c_str());
            cerr<<classname.toStdString()<<endl;
            _currentattrib=QQUICKCOMPONENTWITHNAME(inst,_view,"Attribute");
        }

    }

}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_StateSet_pmoc.cpp"
#endif

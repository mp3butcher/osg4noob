#include <osg/BufferTemplate>
//includes



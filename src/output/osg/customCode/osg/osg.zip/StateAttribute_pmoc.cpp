#include <osg/StateAttribute>
//includes
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/StateAttribute_pmoc.hpp>
using namespace pmoc;
osg::QMLStateAttribute::QMLStateAttribute(pmoc::Instance *i,QObject* parent):QReflect_StateAttribute(i,parent){
//custom initializations
}
QQuickItem* osg::QMLStateAttribute::connect2View(QQuickItem*i){
	this->_view=QReflect_StateAttribute::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLStateAttribute::updateModel(){
	  QReflect_StateAttribute::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_StateAttribute_pmoc.cpp"
#endif



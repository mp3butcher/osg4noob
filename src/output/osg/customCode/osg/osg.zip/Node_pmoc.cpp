#include <osg/Node>
//includes
#include <MetaQQuickLibraryRegistry.h>
#include <iostream>
#include <customCode/osg/Node_pmoc.hpp>

using namespace pmoc;
osg::QMLNode::QMLNode(pmoc::Instance *i,QObject* parent):QReflect_Node(i,parent){
//custom initializations
}
QQuickItem* osg::QMLNode::connect2View(QQuickItem*i){
	this->_view=QReflect_Node::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here


 updateModel();

return this->_view;
}


void  osg::QMLNode::updateModel(){
	  QReflect_Node::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here

	///pop the stateset associated if exists
/*	if(_model->getStateSet()){
	QQuickItem* qmlStateSet;
PMOCQCOMPONENT(*_model->getStateSet(),_view,qmlStateSet);
}*/
Instance inst;

if(_model->getStateSet()){
inst=PMOCADDOBJECT(*_model->getStateSet());
      QQUICKCOMPONENTWITHNAME(  inst,_view,"StateSet");
}
}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_Node_pmoc.cpp"
#endif




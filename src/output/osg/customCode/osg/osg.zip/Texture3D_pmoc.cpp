#include <osg/Texture3D>
//includes
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/Texture3D_pmoc.hpp>
using namespace pmoc;
osg::QMLTexture3D::QMLTexture3D(pmoc::Instance *i,QObject* parent):QReflect_Texture3D(i,parent){
//custom initializations
}
QQuickItem* osg::QMLTexture3D::connect2View(QQuickItem*i){
	this->_view=QReflect_Texture3D::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLTexture3D::updateModel(){
	  QReflect_Texture3D::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_Texture3D_pmoc.cpp"
#endif



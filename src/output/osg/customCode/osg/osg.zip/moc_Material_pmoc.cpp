/****************************************************************************
** Meta object code from reading C++ file 'Material_pmoc.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "Material_pmoc.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Material_pmoc.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_osg__QMLMaterial_t {
    QByteArrayData data[27];
    char stringdata0[356];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLMaterial_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLMaterial_t qt_meta_stringdata_osg__QMLMaterial = {
    {
QT_MOC_LITERAL(0, 0, 16), // "osg::QMLMaterial"
QT_MOC_LITERAL(1, 17, 16), // "diffuseFBChanged"
QT_MOC_LITERAL(2, 34, 0), // ""
QT_MOC_LITERAL(3, 35, 16), // "ambientFBChanged"
QT_MOC_LITERAL(4, 52, 17), // "specularFBChanged"
QT_MOC_LITERAL(5, 70, 15), // "diffuseFChanged"
QT_MOC_LITERAL(6, 86, 15), // "ambientFChanged"
QT_MOC_LITERAL(7, 102, 16), // "specularFChanged"
QT_MOC_LITERAL(8, 119, 15), // "diffuseBChanged"
QT_MOC_LITERAL(9, 135, 15), // "ambientBChanged"
QT_MOC_LITERAL(10, 151, 16), // "specularBChanged"
QT_MOC_LITERAL(11, 168, 18), // "shininessFBChanged"
QT_MOC_LITERAL(12, 187, 17), // "shininessBChanged"
QT_MOC_LITERAL(13, 205, 17), // "shininessFChanged"
QT_MOC_LITERAL(14, 223, 11), // "updateModel"
QT_MOC_LITERAL(15, 235, 9), // "diffuseFB"
QT_MOC_LITERAL(16, 245, 9), // "ambientFB"
QT_MOC_LITERAL(17, 255, 10), // "specularFB"
QT_MOC_LITERAL(18, 266, 11), // "shininessFB"
QT_MOC_LITERAL(19, 278, 8), // "diffuseF"
QT_MOC_LITERAL(20, 287, 8), // "ambientF"
QT_MOC_LITERAL(21, 296, 9), // "specularF"
QT_MOC_LITERAL(22, 306, 10), // "shininessF"
QT_MOC_LITERAL(23, 317, 8), // "diffuseB"
QT_MOC_LITERAL(24, 326, 8), // "ambientB"
QT_MOC_LITERAL(25, 335, 9), // "specularB"
QT_MOC_LITERAL(26, 345, 10) // "shininessB"

    },
    "osg::QMLMaterial\0diffuseFBChanged\0\0"
    "ambientFBChanged\0specularFBChanged\0"
    "diffuseFChanged\0ambientFChanged\0"
    "specularFChanged\0diffuseBChanged\0"
    "ambientBChanged\0specularBChanged\0"
    "shininessFBChanged\0shininessBChanged\0"
    "shininessFChanged\0updateModel\0diffuseFB\0"
    "ambientFB\0specularFB\0shininessFB\0"
    "diffuseF\0ambientF\0specularF\0shininessF\0"
    "diffuseB\0ambientB\0specularB\0shininessB"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLMaterial[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      13,   14, // methods
      12,  116, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   79,    2, 0x06 /* Public */,
       3,    1,   82,    2, 0x06 /* Public */,
       4,    1,   85,    2, 0x06 /* Public */,
       5,    1,   88,    2, 0x06 /* Public */,
       6,    1,   91,    2, 0x06 /* Public */,
       7,    1,   94,    2, 0x06 /* Public */,
       8,    1,   97,    2, 0x06 /* Public */,
       9,    1,  100,    2, 0x06 /* Public */,
      10,    1,  103,    2, 0x06 /* Public */,
      11,    1,  106,    2, 0x06 /* Public */,
      12,    1,  109,    2, 0x06 /* Public */,
      13,    1,  112,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      14,    0,  115,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::QColor,    2,
    QMetaType::Void, QMetaType::Float,    2,
    QMetaType::Void, QMetaType::Float,    2,
    QMetaType::Void, QMetaType::Float,    2,

 // slots: parameters
    QMetaType::Void,

 // properties: name, type, flags
      15, QMetaType::QColor, 0x00495003,
      16, QMetaType::QColor, 0x00495003,
      17, QMetaType::QColor, 0x00495003,
      18, QMetaType::Float, 0x00495003,
      19, QMetaType::QColor, 0x00495003,
      20, QMetaType::QColor, 0x00495003,
      21, QMetaType::QColor, 0x00495003,
      22, QMetaType::Float, 0x00495003,
      23, QMetaType::QColor, 0x00495003,
      24, QMetaType::QColor, 0x00495003,
      25, QMetaType::QColor, 0x00495003,
      26, QMetaType::Float, 0x00495003,

 // properties: notify_signal_id
       0,
       1,
       2,
       9,
       3,
       4,
       5,
      11,
       6,
       7,
       8,
      10,

       0        // eod
};

void osg::QMLMaterial::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLMaterial *_t = static_cast<QMLMaterial *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->diffuseFBChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 1: _t->ambientFBChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 2: _t->specularFBChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 3: _t->diffuseFChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 4: _t->ambientFChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 5: _t->specularFChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 6: _t->diffuseBChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 7: _t->ambientBChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 8: _t->specularBChanged((*reinterpret_cast< QColor(*)>(_a[1]))); break;
        case 9: _t->shininessFBChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 10: _t->shininessBChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 11: _t->shininessFChanged((*reinterpret_cast< float(*)>(_a[1]))); break;
        case 12: _t->updateModel(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::diffuseFBChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::ambientFBChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::specularFBChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::diffuseFChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::ambientFChanged)) {
                *result = 4;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::specularFChanged)) {
                *result = 5;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::diffuseBChanged)) {
                *result = 6;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::ambientBChanged)) {
                *result = 7;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(QColor );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::specularBChanged)) {
                *result = 8;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::shininessFBChanged)) {
                *result = 9;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::shininessBChanged)) {
                *result = 10;
            }
        }
        {
            typedef void (QMLMaterial::*_t)(float );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLMaterial::shininessFChanged)) {
                *result = 11;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QMLMaterial *_t = static_cast<QMLMaterial *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->getdiffuseFB(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = _t->getambientFB(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->getspecularFB(); break;
        case 3: *reinterpret_cast< float*>(_v) = _t->getshininessFB(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->getdiffuseF(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->getambientF(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->getspecularF(); break;
        case 7: *reinterpret_cast< float*>(_v) = _t->getshininessF(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->getdiffuseB(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->getambientB(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->getspecularB(); break;
        case 11: *reinterpret_cast< float*>(_v) = _t->getshininessB(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        QMLMaterial *_t = static_cast<QMLMaterial *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setdiffuseFB(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setambientFB(*reinterpret_cast< QColor*>(_v)); break;
        case 2: _t->setspecularFB(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setshininessFB(*reinterpret_cast< float*>(_v)); break;
        case 4: _t->setdiffuseF(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setambientF(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setspecularF(*reinterpret_cast< QColor*>(_v)); break;
        case 7: _t->setshininessF(*reinterpret_cast< float*>(_v)); break;
        case 8: _t->setdiffuseB(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setambientB(*reinterpret_cast< QColor*>(_v)); break;
        case 10: _t->setspecularB(*reinterpret_cast< QColor*>(_v)); break;
        case 11: _t->setshininessB(*reinterpret_cast< float*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject osg::QMLMaterial::staticMetaObject = {
    { &QReflect_Material::staticMetaObject, qt_meta_stringdata_osg__QMLMaterial.data,
      qt_meta_data_osg__QMLMaterial,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLMaterial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLMaterial::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLMaterial.stringdata0))
        return static_cast<void*>(const_cast< QMLMaterial*>(this));
    return QReflect_Material::qt_metacast(_clname);
}

int osg::QMLMaterial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_Material::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 13)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 13;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 12;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 12;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void osg::QMLMaterial::diffuseFBChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void osg::QMLMaterial::ambientFBChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void osg::QMLMaterial::specularFBChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void osg::QMLMaterial::diffuseFChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void osg::QMLMaterial::ambientFChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void osg::QMLMaterial::specularFChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void osg::QMLMaterial::diffuseBChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void osg::QMLMaterial::ambientBChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void osg::QMLMaterial::specularBChanged(QColor _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void osg::QMLMaterial::shininessFBChanged(float _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void osg::QMLMaterial::shininessBChanged(float _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void osg::QMLMaterial::shininessFChanged(float _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
QT_END_MOC_NAMESPACE

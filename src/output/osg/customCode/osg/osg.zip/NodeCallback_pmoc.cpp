#include <osg/NodeCallback>
//includes



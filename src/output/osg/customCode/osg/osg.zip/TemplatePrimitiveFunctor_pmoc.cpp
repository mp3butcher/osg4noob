#include <osg/TemplatePrimitiveFunctor>
//includes



/****************************************************************************
** Meta object code from reading C++ file 'Geometry_pmoc.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "Geometry_pmoc.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Geometry_pmoc.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_osg__QMLGeometry_t {
    QByteArrayData data[12];
    char stringdata0[226];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLGeometry_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLGeometry_t qt_meta_stringdata_osg__QMLGeometry = {
    {
QT_MOC_LITERAL(0, 0, 16), // "osg::QMLGeometry"
QT_MOC_LITERAL(1, 17, 25), // "vertexAttribArraysChanged"
QT_MOC_LITERAL(2, 43, 0), // ""
QT_MOC_LITERAL(3, 44, 27), // "pmoc::StateAttribListModel*"
QT_MOC_LITERAL(4, 72, 11), // "updateModel"
QT_MOC_LITERAL(5, 84, 22), // "popSelectedVertexArray"
QT_MOC_LITERAL(6, 107, 2), // "id"
QT_MOC_LITERAL(7, 110, 20), // "addVertexAttribArray"
QT_MOC_LITERAL(8, 131, 20), // "osg::QReflect_Array*"
QT_MOC_LITERAL(9, 152, 33), // "pmoc_reverse_addVertexAttribA..."
QT_MOC_LITERAL(10, 186, 20), // "generateTangentSpace"
QT_MOC_LITERAL(11, 207, 18) // "vertexAttribArrays"

    },
    "osg::QMLGeometry\0vertexAttribArraysChanged\0"
    "\0pmoc::StateAttribListModel*\0updateModel\0"
    "popSelectedVertexArray\0id\0"
    "addVertexAttribArray\0osg::QReflect_Array*\0"
    "pmoc_reverse_addVertexAttribArray\0"
    "generateTangentSpace\0vertexAttribArrays"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLGeometry[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       1,   62, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   44,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,   47,    2, 0x0a /* Public */,
       5,    1,   48,    2, 0x0a /* Public */,

 // methods: name, argc, parameters, tag, flags
       7,    1,   51,    2, 0x02 /* Public */,
       9,    1,   54,    2, 0x02 /* Public */,
      10,    2,   57,    2, 0x02 /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,

 // methods: parameters
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void, 0x80000000 | 8,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,

 // properties: name, type, flags
      11, 0x80000000 | 3, 0x00495009,

 // properties: notify_signal_id
       0,

       0        // eod
};

void osg::QMLGeometry::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLGeometry *_t = static_cast<QMLGeometry *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->vertexAttribArraysChanged((*reinterpret_cast< pmoc::StateAttribListModel*(*)>(_a[1]))); break;
        case 1: _t->updateModel(); break;
        case 2: _t->popSelectedVertexArray((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->addVertexAttribArray((*reinterpret_cast< osg::QReflect_Array*(*)>(_a[1]))); break;
        case 4: _t->pmoc_reverse_addVertexAttribArray((*reinterpret_cast< osg::QReflect_Array*(*)>(_a[1]))); break;
        case 5: _t->generateTangentSpace((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QMLGeometry::*_t)(pmoc::StateAttribListModel * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QMLGeometry::vertexAttribArraysChanged)) {
                *result = 0;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        QMLGeometry *_t = static_cast<QMLGeometry *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< pmoc::StateAttribListModel**>(_v) = _t->vertexAttribArrays(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

const QMetaObject osg::QMLGeometry::staticMetaObject = {
    { &QReflect_Geometry::staticMetaObject, qt_meta_stringdata_osg__QMLGeometry.data,
      qt_meta_data_osg__QMLGeometry,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLGeometry::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLGeometry::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLGeometry.stringdata0))
        return static_cast<void*>(const_cast< QMLGeometry*>(this));
    return QReflect_Geometry::qt_metacast(_clname);
}

int osg::QMLGeometry::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_Geometry::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void osg::QMLGeometry::vertexAttribArraysChanged(pmoc::StateAttribListModel * _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_deprecated_osg__QMLGeometry_t {
    QByteArrayData data[1];
    char stringdata0[28];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_deprecated_osg__QMLGeometry_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_deprecated_osg__QMLGeometry_t qt_meta_stringdata_deprecated_osg__QMLGeometry = {
    {
QT_MOC_LITERAL(0, 0, 27) // "deprecated_osg::QMLGeometry"

    },
    "deprecated_osg::QMLGeometry"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_deprecated_osg__QMLGeometry[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void deprecated_osg::QMLGeometry::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject deprecated_osg::QMLGeometry::staticMetaObject = {
    { &QReflect_Geometry::staticMetaObject, qt_meta_stringdata_deprecated_osg__QMLGeometry.data,
      qt_meta_data_deprecated_osg__QMLGeometry,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *deprecated_osg::QMLGeometry::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *deprecated_osg::QMLGeometry::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_deprecated_osg__QMLGeometry.stringdata0))
        return static_cast<void*>(const_cast< QMLGeometry*>(this));
    return QReflect_Geometry::qt_metacast(_clname);
}

int deprecated_osg::QMLGeometry::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_Geometry::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE

#include <osg/Group>
//includes
#include <customCode/osg/Group_pmoc.hpp>
#include <MetaQQuickLibraryRegistry.h>
#include <MetaQQuickLibraryRegistry.h>
#include <osgDB/ReadFile>
#include <osgDB/FileUtils>
using namespace std;
using namespace pmoc;

osg::QMLGroup::QMLGroup(pmoc::Instance *i,QObject* parent):QReflect_Group(i,parent)
{
    ///custom initializations
    qmlRegisterType<pmoc::StateAttribListModel>();

}
QQuickItem* osg::QMLGroup::connect2View(QQuickItem*i)
{
    this->_view=QReflect_Group::connect2View(i);
    ///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
    ///CustomiZE here
    updateModel();

    emit childrenChanged(&_qchildren);
    return this->_view;
}
void osg::QMLGroup::updateModel()
{
    _qchildren.resetListViewModel();
    for(int i=0; i<_model->getNumChildren(); i++)
    {

        osg::Node *dr=_model->getChild(i);

        PMOCSAFEADDOBJECT( *dr,inst);
        QString classname=QString( inst.model->id().c_str());
        pmoc::StateAttribObject dra(QString( dr->getName().c_str()),classname);
        _qchildren.addStateAttrib(dra);

    }
    emit childrenChanged(&_qchildren );

}

void osg::QMLGroup::childSelected(int i)
{
    ///get QuickComponent for children i
    if(_model->getChild(i)){
   // PMOCQCOMPONENT(*_model->getChild(i),_view,_clickedchild);

        PMOCSAFEADDOBJECT( *_model->getChild(i),inst);
        _clickedchild=QQUICKCOMPONENTWITHNAME(inst,_view,"Child");
}
}

void osg::QMLGroup::addChildFromFile(QUrl sss)
{



    QString s = sss.toLocalFile();//    QString s = sss.replace("file://", "");
    /*cout<<"wiriting filemen"<<endl;
    cout<<osgDB::getCurrentWorkingDirectory()<<endl;
    cout<<osgDB::getPathRelative(osgDB::getCurrentWorkingDirectory()+"/",s.toStdString())<<endl;
    */
    QString curpath=QString(osgDB::getCurrentWorkingDirectory().c_str()).replace("\\","/")+"/";///replace \ in osg path
    s=s.replace(curpath,QString(""));
    cout<<"selected image file"<< s.toStdString()<<endl;


    osg::ref_ptr<osg::Node>n=osgDB::readNodeFile(s.toStdString());



    if (n.get())
    {
        _model->addChild(n);
        emit modelChanged();
    }
}


#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_Group_pmoc.cpp"
#endif

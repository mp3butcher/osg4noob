#include <osg/Vec3>
//includes



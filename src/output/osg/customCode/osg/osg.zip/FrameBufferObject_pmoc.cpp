#include <osg/FrameBufferObject>
//includes
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/FrameBufferObject_pmoc.hpp>
using namespace pmoc;
osg::QMLFrameBufferAttachment::QMLFrameBufferAttachment(pmoc::Instance *i,QObject* parent):QReflect_FrameBufferAttachment(i,parent){
//custom initializations
}
QQuickItem* osg::QMLFrameBufferAttachment::connect2View(QQuickItem*i){
	this->_view=QReflect_FrameBufferAttachment::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLFrameBufferAttachment::updateModel(){
	  QReflect_FrameBufferAttachment::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_FrameBufferObject_pmoc.cpp"
#endif
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/FrameBufferObject_pmoc.hpp>
using namespace pmoc;
osg::QMLFrameBufferObject::QMLFrameBufferObject(pmoc::Instance *i,QObject* parent):QReflect_FrameBufferObject(i,parent){
//custom initializations
}
QQuickItem* osg::QMLFrameBufferObject::connect2View(QQuickItem*i){
	this->_view=QReflect_FrameBufferObject::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLFrameBufferObject::updateModel(){
	  QReflect_FrameBufferObject::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_FrameBufferObject_pmoc.cpp"
#endif
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/FrameBufferObject_pmoc.hpp>
using namespace pmoc;
osg::QMLRenderBuffer::QMLRenderBuffer(pmoc::Instance *i,QObject* parent):QReflect_RenderBuffer(i,parent){
//custom initializations
}
QQuickItem* osg::QMLRenderBuffer::connect2View(QQuickItem*i){
	this->_view=QReflect_RenderBuffer::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLRenderBuffer::updateModel(){
	  QReflect_RenderBuffer::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_FrameBufferObject_pmoc.cpp"
#endif




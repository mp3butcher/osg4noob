#include <osg/Camera>
//includes
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/Camera_pmoc.hpp>
using namespace pmoc;
osg::QMLCamera::QMLCamera(pmoc::Instance *i,QObject* parent):QReflect_Camera(i,parent){
//custom initializations
}
QQuickItem* osg::QMLCamera::connect2View(QQuickItem*i){
	this->_view=QReflect_Camera::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLCamera::updateModel(){
	  QReflect_Camera::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_Camera_pmoc.cpp"
#endif
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/Camera_pmoc.hpp>
using namespace pmoc;
osg::QMLCameraRenderOrderSortOp::QMLCameraRenderOrderSortOp(pmoc::Instance *i,QObject* parent):QReflect_CameraRenderOrderSortOp(i,parent){
//custom initializations
}
QQuickItem* osg::QMLCameraRenderOrderSortOp::connect2View(QQuickItem*i){
	this->_view=QReflect_CameraRenderOrderSortOp::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLCameraRenderOrderSortOp::updateModel(){
	  QReflect_CameraRenderOrderSortOp::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_Camera_pmoc.cpp"
#endif




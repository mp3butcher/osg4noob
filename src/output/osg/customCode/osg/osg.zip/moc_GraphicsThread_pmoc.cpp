/****************************************************************************
** Meta object code from reading C++ file 'GraphicsThread_pmoc.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "GraphicsThread_pmoc.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'GraphicsThread_pmoc.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_osg__QMLGraphicsOperation_t {
    QByteArrayData data[3];
    char stringdata0[39];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLGraphicsOperation_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLGraphicsOperation_t qt_meta_stringdata_osg__QMLGraphicsOperation = {
    {
QT_MOC_LITERAL(0, 0, 25), // "osg::QMLGraphicsOperation"
QT_MOC_LITERAL(1, 26, 11), // "updateModel"
QT_MOC_LITERAL(2, 38, 0) // ""

    },
    "osg::QMLGraphicsOperation\0updateModel\0"
    ""
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLGraphicsOperation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLGraphicsOperation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLGraphicsOperation *_t = static_cast<QMLGraphicsOperation *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLGraphicsOperation::staticMetaObject = {
    { &QReflect_GraphicsOperation::staticMetaObject, qt_meta_stringdata_osg__QMLGraphicsOperation.data,
      qt_meta_data_osg__QMLGraphicsOperation,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLGraphicsOperation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLGraphicsOperation::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLGraphicsOperation.stringdata0))
        return static_cast<void*>(const_cast< QMLGraphicsOperation*>(this));
    return QReflect_GraphicsOperation::qt_metacast(_clname);
}

int osg::QMLGraphicsOperation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_GraphicsOperation::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLEndOfDynamicDrawBlock_t {
    QByteArrayData data[3];
    char stringdata0[43];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLEndOfDynamicDrawBlock_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLEndOfDynamicDrawBlock_t qt_meta_stringdata_osg__QMLEndOfDynamicDrawBlock = {
    {
QT_MOC_LITERAL(0, 0, 29), // "osg::QMLEndOfDynamicDrawBlock"
QT_MOC_LITERAL(1, 30, 11), // "updateModel"
QT_MOC_LITERAL(2, 42, 0) // ""

    },
    "osg::QMLEndOfDynamicDrawBlock\0updateModel\0"
    ""
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLEndOfDynamicDrawBlock[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLEndOfDynamicDrawBlock::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLEndOfDynamicDrawBlock *_t = static_cast<QMLEndOfDynamicDrawBlock *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLEndOfDynamicDrawBlock::staticMetaObject = {
    { &QReflect_EndOfDynamicDrawBlock::staticMetaObject, qt_meta_stringdata_osg__QMLEndOfDynamicDrawBlock.data,
      qt_meta_data_osg__QMLEndOfDynamicDrawBlock,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLEndOfDynamicDrawBlock::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLEndOfDynamicDrawBlock::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLEndOfDynamicDrawBlock.stringdata0))
        return static_cast<void*>(const_cast< QMLEndOfDynamicDrawBlock*>(this));
    return QReflect_EndOfDynamicDrawBlock::qt_metacast(_clname);
}

int osg::QMLEndOfDynamicDrawBlock::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_EndOfDynamicDrawBlock::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLBlockAndFlushOperation_t {
    QByteArrayData data[3];
    char stringdata0[44];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLBlockAndFlushOperation_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLBlockAndFlushOperation_t qt_meta_stringdata_osg__QMLBlockAndFlushOperation = {
    {
QT_MOC_LITERAL(0, 0, 30), // "osg::QMLBlockAndFlushOperation"
QT_MOC_LITERAL(1, 31, 11), // "updateModel"
QT_MOC_LITERAL(2, 43, 0) // ""

    },
    "osg::QMLBlockAndFlushOperation\0"
    "updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLBlockAndFlushOperation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLBlockAndFlushOperation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLBlockAndFlushOperation *_t = static_cast<QMLBlockAndFlushOperation *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLBlockAndFlushOperation::staticMetaObject = {
    { &QReflect_BlockAndFlushOperation::staticMetaObject, qt_meta_stringdata_osg__QMLBlockAndFlushOperation.data,
      qt_meta_data_osg__QMLBlockAndFlushOperation,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLBlockAndFlushOperation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLBlockAndFlushOperation::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLBlockAndFlushOperation.stringdata0))
        return static_cast<void*>(const_cast< QMLBlockAndFlushOperation*>(this));
    return QReflect_BlockAndFlushOperation::qt_metacast(_clname);
}

int osg::QMLBlockAndFlushOperation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_BlockAndFlushOperation::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLSwapBuffersOperation_t {
    QByteArrayData data[3];
    char stringdata0[42];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLSwapBuffersOperation_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLSwapBuffersOperation_t qt_meta_stringdata_osg__QMLSwapBuffersOperation = {
    {
QT_MOC_LITERAL(0, 0, 28), // "osg::QMLSwapBuffersOperation"
QT_MOC_LITERAL(1, 29, 11), // "updateModel"
QT_MOC_LITERAL(2, 41, 0) // ""

    },
    "osg::QMLSwapBuffersOperation\0updateModel\0"
    ""
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLSwapBuffersOperation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLSwapBuffersOperation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLSwapBuffersOperation *_t = static_cast<QMLSwapBuffersOperation *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLSwapBuffersOperation::staticMetaObject = {
    { &QReflect_SwapBuffersOperation::staticMetaObject, qt_meta_stringdata_osg__QMLSwapBuffersOperation.data,
      qt_meta_data_osg__QMLSwapBuffersOperation,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLSwapBuffersOperation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLSwapBuffersOperation::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLSwapBuffersOperation.stringdata0))
        return static_cast<void*>(const_cast< QMLSwapBuffersOperation*>(this));
    return QReflect_SwapBuffersOperation::qt_metacast(_clname);
}

int osg::QMLSwapBuffersOperation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_SwapBuffersOperation::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLRunOperations_t {
    QByteArrayData data[3];
    char stringdata0[35];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLRunOperations_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLRunOperations_t qt_meta_stringdata_osg__QMLRunOperations = {
    {
QT_MOC_LITERAL(0, 0, 21), // "osg::QMLRunOperations"
QT_MOC_LITERAL(1, 22, 11), // "updateModel"
QT_MOC_LITERAL(2, 34, 0) // ""

    },
    "osg::QMLRunOperations\0updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLRunOperations[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLRunOperations::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLRunOperations *_t = static_cast<QMLRunOperations *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLRunOperations::staticMetaObject = {
    { &QReflect_RunOperations::staticMetaObject, qt_meta_stringdata_osg__QMLRunOperations.data,
      qt_meta_data_osg__QMLRunOperations,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLRunOperations::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLRunOperations::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLRunOperations.stringdata0))
        return static_cast<void*>(const_cast< QMLRunOperations*>(this));
    return QReflect_RunOperations::qt_metacast(_clname);
}

int osg::QMLRunOperations::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_RunOperations::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLGraphicsThread_t {
    QByteArrayData data[3];
    char stringdata0[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLGraphicsThread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLGraphicsThread_t qt_meta_stringdata_osg__QMLGraphicsThread = {
    {
QT_MOC_LITERAL(0, 0, 22), // "osg::QMLGraphicsThread"
QT_MOC_LITERAL(1, 23, 11), // "updateModel"
QT_MOC_LITERAL(2, 35, 0) // ""

    },
    "osg::QMLGraphicsThread\0updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLGraphicsThread[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLGraphicsThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLGraphicsThread *_t = static_cast<QMLGraphicsThread *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLGraphicsThread::staticMetaObject = {
    { &QReflect_GraphicsThread::staticMetaObject, qt_meta_stringdata_osg__QMLGraphicsThread.data,
      qt_meta_data_osg__QMLGraphicsThread,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLGraphicsThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLGraphicsThread::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLGraphicsThread.stringdata0))
        return static_cast<void*>(const_cast< QMLGraphicsThread*>(this));
    return QReflect_GraphicsThread::qt_metacast(_clname);
}

int osg::QMLGraphicsThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_GraphicsThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLFlushDeletedGLObjectsOperation_t {
    QByteArrayData data[3];
    char stringdata0[52];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLFlushDeletedGLObjectsOperation_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLFlushDeletedGLObjectsOperation_t qt_meta_stringdata_osg__QMLFlushDeletedGLObjectsOperation = {
    {
QT_MOC_LITERAL(0, 0, 38), // "osg::QMLFlushDeletedGLObjects..."
QT_MOC_LITERAL(1, 39, 11), // "updateModel"
QT_MOC_LITERAL(2, 51, 0) // ""

    },
    "osg::QMLFlushDeletedGLObjectsOperation\0"
    "updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLFlushDeletedGLObjectsOperation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLFlushDeletedGLObjectsOperation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLFlushDeletedGLObjectsOperation *_t = static_cast<QMLFlushDeletedGLObjectsOperation *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLFlushDeletedGLObjectsOperation::staticMetaObject = {
    { &QReflect_FlushDeletedGLObjectsOperation::staticMetaObject, qt_meta_stringdata_osg__QMLFlushDeletedGLObjectsOperation.data,
      qt_meta_data_osg__QMLFlushDeletedGLObjectsOperation,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLFlushDeletedGLObjectsOperation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLFlushDeletedGLObjectsOperation::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLFlushDeletedGLObjectsOperation.stringdata0))
        return static_cast<void*>(const_cast< QMLFlushDeletedGLObjectsOperation*>(this));
    return QReflect_FlushDeletedGLObjectsOperation::qt_metacast(_clname);
}

int osg::QMLFlushDeletedGLObjectsOperation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_FlushDeletedGLObjectsOperation::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLBarrierOperation_t {
    QByteArrayData data[3];
    char stringdata0[38];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLBarrierOperation_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLBarrierOperation_t qt_meta_stringdata_osg__QMLBarrierOperation = {
    {
QT_MOC_LITERAL(0, 0, 24), // "osg::QMLBarrierOperation"
QT_MOC_LITERAL(1, 25, 11), // "updateModel"
QT_MOC_LITERAL(2, 37, 0) // ""

    },
    "osg::QMLBarrierOperation\0updateModel\0"
    ""
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLBarrierOperation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLBarrierOperation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLBarrierOperation *_t = static_cast<QMLBarrierOperation *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLBarrierOperation::staticMetaObject = {
    { &QReflect_BarrierOperation::staticMetaObject, qt_meta_stringdata_osg__QMLBarrierOperation.data,
      qt_meta_data_osg__QMLBarrierOperation,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLBarrierOperation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLBarrierOperation::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLBarrierOperation.stringdata0))
        return static_cast<void*>(const_cast< QMLBarrierOperation*>(this));
    return QReflect_BarrierOperation::qt_metacast(_clname);
}

int osg::QMLBarrierOperation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_BarrierOperation::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLReleaseContext_Block_MakeCurrentOperation_t {
    QByteArrayData data[3];
    char stringdata0[63];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLReleaseContext_Block_MakeCurrentOperation_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLReleaseContext_Block_MakeCurrentOperation_t qt_meta_stringdata_osg__QMLReleaseContext_Block_MakeCurrentOperation = {
    {
QT_MOC_LITERAL(0, 0, 49), // "osg::QMLReleaseContext_Block_..."
QT_MOC_LITERAL(1, 50, 11), // "updateModel"
QT_MOC_LITERAL(2, 62, 0) // ""

    },
    "osg::QMLReleaseContext_Block_MakeCurrentOperation\0"
    "updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLReleaseContext_Block_MakeCurrentOperation[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLReleaseContext_Block_MakeCurrentOperation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLReleaseContext_Block_MakeCurrentOperation *_t = static_cast<QMLReleaseContext_Block_MakeCurrentOperation *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLReleaseContext_Block_MakeCurrentOperation::staticMetaObject = {
    { &QReflect_ReleaseContext_Block_MakeCurrentOperation::staticMetaObject, qt_meta_stringdata_osg__QMLReleaseContext_Block_MakeCurrentOperation.data,
      qt_meta_data_osg__QMLReleaseContext_Block_MakeCurrentOperation,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLReleaseContext_Block_MakeCurrentOperation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLReleaseContext_Block_MakeCurrentOperation::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLReleaseContext_Block_MakeCurrentOperation.stringdata0))
        return static_cast<void*>(const_cast< QMLReleaseContext_Block_MakeCurrentOperation*>(this));
    return QReflect_ReleaseContext_Block_MakeCurrentOperation::qt_metacast(_clname);
}

int osg::QMLReleaseContext_Block_MakeCurrentOperation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_ReleaseContext_Block_MakeCurrentOperation::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

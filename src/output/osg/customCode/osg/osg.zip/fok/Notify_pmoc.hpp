#ifndef osg_Notify_customHPP
#define  osg_Notify_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Notify_pmoc.hpp>
#include <QObject>
#include <osg/Notify>

#include <osg/Notify_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLNotifyHandler: public QReflect_NotifyHandler
{
Q_OBJECT
public:
QMLNotifyHandler(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLNotifyHandler)
#include <osg/Notify_pmoc.hpp>
#include <QObject>
#include <osg/Notify>
 
#include <osg/Notify_pmoc.hpp>
#include <QObject>
#include <osg/Notify>

#include <osg/Notify_pmoc.hpp>
#include <osg/Notify_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLStandardNotifyHandler: public QReflect_StandardNotifyHandler
{
Q_OBJECT
public:
QMLStandardNotifyHandler(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLStandardNotifyHandler)

#endif //osg_Notify_customHPP


#ifndef osg_Texture_customHPP
#define  osg_Texture_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Texture_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Vec4d;
			} ;
namespace osg{ 
class QReflect_Vec4i;
			} ;
namespace osg{ 
class QReflect_GraphicsContext;
			} ;
#include <osg/GraphicsContext>
#include <osg/GraphicsContext_pmoc.hpp>
#include <osg/StateAttribute_pmoc.hpp>
#include <osg/Texture>

#include <osg/Vec4d>
#include <osg/Vec4d_pmoc.hpp>
#include <osg/Vec4i>
#include <osg/Vec4i_pmoc.hpp>
#include <osg/Texture_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexture: public QReflect_Texture
{
Q_OBJECT
public:
QMLTexture(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexture)

#endif //osg_Texture_customHPP


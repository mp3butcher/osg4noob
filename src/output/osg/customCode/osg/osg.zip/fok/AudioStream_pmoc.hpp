#ifndef osg_AudioStream_customHPP
#define  osg_AudioStream_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/AudioStream_pmoc.hpp>
#include <QObject>
#include <osg/AudioStream>

#include <osg/Object_pmoc.hpp>
#include <osg/AudioStream_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLAudioStream: public QReflect_AudioStream
{
Q_OBJECT
public:
QMLAudioStream(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLAudioStream)
#include <osg/AudioStream_pmoc.hpp>
#include <QObject>
#include <osg/AudioStream>

#include <osg/Object_pmoc.hpp>
#include <osg/AudioStream_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLAudioSink: public QReflect_AudioSink
{
Q_OBJECT
public:
QMLAudioSink(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLAudioSink)

#endif //osg_AudioStream_customHPP


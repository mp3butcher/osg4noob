#ifndef osg_Vec2f_customHPP
#define  osg_Vec2f_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Vec2f_pmoc.hpp>
#include <QObject>
#include <osg/Vec2f>

#include <osg/Vec2f_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLVec2f: public QReflect_Vec2f
{
Q_OBJECT
public:
QMLVec2f(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLVec2f)

#endif //osg_Vec2f_customHPP


#ifndef osg_StencilTwoSided_customHPP
#define  osg_StencilTwoSided_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/StencilTwoSided_pmoc.hpp>
#include <QObject>
#include <osg/StateAttribute_pmoc.hpp>
#include <osg/StencilTwoSided>

#include <osg/StencilTwoSided_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLStencilTwoSided: public QReflect_StencilTwoSided
{
Q_OBJECT
public:
QMLStencilTwoSided(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLStencilTwoSided)

#endif //osg_StencilTwoSided_customHPP


#ifndef osg_Scissor_customHPP
#define  osg_Scissor_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Scissor_pmoc.hpp>
#include <QObject>
#include <osg/Scissor>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/Scissor_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLScissor: public QReflect_Scissor
{
Q_OBJECT
public:
QMLScissor(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLScissor)

#endif //osg_Scissor_customHPP


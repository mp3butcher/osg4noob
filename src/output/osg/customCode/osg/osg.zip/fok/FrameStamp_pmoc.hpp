#ifndef osg_FrameStamp_customHPP
#define  osg_FrameStamp_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/FrameStamp_pmoc.hpp>
#include <QObject>
#include <osg/FrameStamp>

#include <osg/Referenced_pmoc.hpp>
#include <osg/FrameStamp_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLFrameStamp: public QReflect_FrameStamp
{
Q_OBJECT
public:
QMLFrameStamp(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLFrameStamp)

#endif //osg_FrameStamp_customHPP


#ifndef osg_Texture2DMultisample_customHPP
#define  osg_Texture2DMultisample_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Texture2DMultisample_pmoc.hpp>
#include <QObject>
#include <osg/Texture2DMultisample>

#include <osg/Texture_pmoc.hpp>
#include <osg/Texture2DMultisample_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexture2DMultisample: public QReflect_Texture2DMultisample
{
Q_OBJECT
public:
QMLTexture2DMultisample(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexture2DMultisample)

#endif //osg_Texture2DMultisample_customHPP


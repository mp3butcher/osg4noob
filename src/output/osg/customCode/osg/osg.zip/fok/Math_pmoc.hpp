#ifndef osg_Math_customHPP
#define  osg_Math_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_Math_customHPP


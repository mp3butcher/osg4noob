#ifndef osg_buffered_value_customHPP
#define  osg_buffered_value_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_buffered_value_customHPP


#ifndef osg_BlendColor_customHPP
#define  osg_BlendColor_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/BlendColor_pmoc.hpp>
#include <QObject>
#include <osg/BlendColor>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/BlendColor_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLBlendColor: public QReflect_BlendColor
{
Q_OBJECT
public:
QMLBlendColor(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLBlendColor)

#endif //osg_BlendColor_customHPP


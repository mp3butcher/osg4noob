#ifndef osg_TexGenNode_customHPP
#define  osg_TexGenNode_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/TexGenNode_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_TexGen;
			} ;
#include <osg/Group_pmoc.hpp>
#include <osg/TexGen>
#include <osg/TexGenNode>

#include <osg/TexGen_pmoc.hpp>
#include <osg/TexGenNode_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexGenNode: public QReflect_TexGenNode
{
Q_OBJECT
public:
QMLTexGenNode(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexGenNode)

#endif //osg_TexGenNode_customHPP


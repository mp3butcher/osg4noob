#ifndef osg_Geometry_customHPP
#define  osg_Geometry_customHPP 1
#include "../../Export.h"
//includes
#include <osg/Geometry_pmoc.hpp>
#include <QObject>
#include <osg/Geometry>

#include <osg/Geometry_pmoc.hpp>
#include <customCode/osg/AttribListModel.hpp>
namespace osg
{
class osgPMOC_EXPORTS QMLGeometry: public QReflect_Geometry
{
    Q_PROPERTY(pmoc::StateAttribListModel* vertexAttribArrays READ vertexAttribArrays NOTIFY vertexAttribArraysChanged)
    Q_OBJECT
public:
    QMLGeometry(pmoc::Instance *i=0,QObject* parent=0);

///add attrib array to the first unsettted index
    Q_INVOKABLE void addVertexAttribArray(osg::QReflect_Array*);
///find in ordered collection and remove
    Q_INVOKABLE void pmoc_reverse_addVertexAttribArray(osg::QReflect_Array*);


    virtual QQuickItem * connect2View(QQuickItem*);
//Q_PROPERTY(QQmlListProperty<pmoc::StateAttribObject> drawables READ getDrawables NOTIFY drawablesChanged)
    pmoc::StateAttribListModel* vertexAttribArrays()
    {
        return &_qvertexAttribArray;
    }
signals:
    void vertexAttribArraysChanged(pmoc::StateAttribListModel* );
public slots:
    virtual void updateModel();
public:
    Q_INVOKABLE void generateTangentSpace(int ,int );
protected:
    pmoc::StateAttribListModel _qvertexAttribArray;
public slots:
    void popSelectedVertexArray(int id);
};

}
Q_DECLARE_METATYPE(osg::QMLGeometry)

#include <osg/Geometry_pmoc.hpp>
#include <QObject>
#include <osg/Geometry>

#include <osg/Geometry_pmoc.hpp>
#include <osg/Geometry_pmoc.hpp>
namespace deprecated_osg
{
class osgPMOC_EXPORTS QMLGeometry: public QReflect_Geometry
{
    Q_OBJECT
public:
    QMLGeometry(pmoc::Instance *i=0,QObject* parent=0);
    virtual QQuickItem * connect2View(QQuickItem*);

};

}
Q_DECLARE_METATYPE(deprecated_osg::QMLGeometry)

#endif //osg_Geometry_customHPP


#ifndef osg_GLDefines_customHPP
#define  osg_GLDefines_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_GLDefines_customHPP


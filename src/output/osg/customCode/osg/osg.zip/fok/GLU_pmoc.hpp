#ifndef osg_GLU_customHPP
#define  osg_GLU_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/GLU_pmoc.hpp>
#include <QObject>
#include <osg/GLU>

#include <osg/GLU_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLPixelStorageModes: public QReflect_PixelStorageModes
{
Q_OBJECT
public:
QMLPixelStorageModes(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLPixelStorageModes)

#endif //osg_GLU_customHPP


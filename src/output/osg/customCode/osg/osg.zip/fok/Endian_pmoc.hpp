#ifndef osg_Endian_customHPP
#define  osg_Endian_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_Endian_customHPP


#ifndef osg_DisplaySettings_customHPP
#define  osg_DisplaySettings_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/DisplaySettings_pmoc.hpp>
#include <QObject>
#include <osg/DisplaySettings>

#include <osg/Referenced_pmoc.hpp>
#include <osg/DisplaySettings_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDisplaySettings: public QReflect_DisplaySettings
{
Q_OBJECT
public:
QMLDisplaySettings(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDisplaySettings)

#endif //osg_DisplaySettings_customHPP


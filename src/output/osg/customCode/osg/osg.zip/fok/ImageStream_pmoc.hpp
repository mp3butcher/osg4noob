#ifndef osg_ImageStream_customHPP
#define  osg_ImageStream_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/ImageStream_pmoc.hpp>
#include <QObject>
#include <osg/ImageStream>

#include <osg/Image_pmoc.hpp>
#include <osg/ImageStream_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLImageStream: public QReflect_ImageStream
{
Q_OBJECT
public:
QMLImageStream(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLImageStream)

#endif //osg_ImageStream_customHPP


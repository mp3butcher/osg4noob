#ifndef osg_Texture3D_customHPP
#define  osg_Texture3D_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Texture3D_pmoc.hpp>
#include <QObject>
#include <osg/Texture3D>

#include <osg/Texture_pmoc.hpp>
#include <osg/Texture3D_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexture3D: public QReflect_Texture3D
{
Q_OBJECT
public:
QMLTexture3D(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexture3D)

#endif //osg_Texture3D_customHPP


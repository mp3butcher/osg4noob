#ifndef osg_Multisample_customHPP
#define  osg_Multisample_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Multisample_pmoc.hpp>
#include <QObject>
#include <osg/Multisample>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/Multisample_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLMultisample: public QReflect_Multisample
{
Q_OBJECT
public:
QMLMultisample(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLMultisample)

#endif //osg_Multisample_customHPP


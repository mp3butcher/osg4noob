#ifndef osg_MixinVector_customHPP
#define  osg_MixinVector_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_MixinVector_customHPP


#ifndef osg_ShaderAttribute_customHPP
#define  osg_ShaderAttribute_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/ShaderAttribute_pmoc.hpp>
#include <QObject>
#include <osg/ShaderAttribute>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/ShaderAttribute_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLShaderAttribute: public QReflect_ShaderAttribute
{
Q_OBJECT
public:
QMLShaderAttribute(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLShaderAttribute)

#endif //osg_ShaderAttribute_customHPP


#ifndef osg_Version_customHPP
#define  osg_Version_customHPP 1
#include "../../Export.h" 
//includes
#endif //osg_Version_customHPP


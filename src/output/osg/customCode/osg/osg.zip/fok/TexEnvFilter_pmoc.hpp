#ifndef osg_TexEnvFilter_customHPP
#define  osg_TexEnvFilter_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/TexEnvFilter_pmoc.hpp>
#include <QObject>
#include <osg/StateAttribute_pmoc.hpp>
#include <osg/TexEnvFilter>

#include <osg/TexEnvFilter_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexEnvFilter: public QReflect_TexEnvFilter
{
Q_OBJECT
public:
QMLTexEnvFilter(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexEnvFilter)

#endif //osg_TexEnvFilter_customHPP


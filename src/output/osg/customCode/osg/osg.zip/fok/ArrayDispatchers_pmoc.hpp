#ifndef osg_ArrayDispatchers_customHPP
#define  osg_ArrayDispatchers_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/ArrayDispatchers_pmoc.hpp>
#include <QObject>
#include <osg/ArrayDispatchers>

#include <osg/Referenced_pmoc.hpp>
#include <osg/ArrayDispatchers_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLArrayDispatchers: public QReflect_ArrayDispatchers
{
Q_OBJECT
public:
QMLArrayDispatchers(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLArrayDispatchers)
#include <osg/ArrayDispatchers_pmoc.hpp>
#include <QObject>
#include <osg/ArrayDispatchers>

#include <osg/Referenced_pmoc.hpp>
#include <osg/ArrayDispatchers_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLAttributeDispatch: public QReflect_AttributeDispatch
{
Q_OBJECT
public:
QMLAttributeDispatch(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLAttributeDispatch)

#endif //osg_ArrayDispatchers_customHPP


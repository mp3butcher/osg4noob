#ifndef osg_GL_customHPP
#define  osg_GL_customHPP 1
#include "../../Export.h" 
//includes
#endif //osg_GL_customHPP


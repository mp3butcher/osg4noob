#ifndef osg_ref_ptr_customHPP
#define  osg_ref_ptr_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_ref_ptr_customHPP


#ifndef osg_Vec2_customHPP
#define  osg_Vec2_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_Vec2_customHPP


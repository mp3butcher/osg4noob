#ifndef osg_GraphicsCostEstimator_customHPP
#define  osg_GraphicsCostEstimator_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/GraphicsCostEstimator_pmoc.hpp>
#include <QObject>
#include <osg/GraphicsCostEstimator>

#include <osg/Referenced_pmoc.hpp>
#include <osg/GraphicsCostEstimator_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLGraphicsCostEstimator: public QReflect_GraphicsCostEstimator
{
Q_OBJECT
public:
QMLGraphicsCostEstimator(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLGraphicsCostEstimator)
#include <osg/GraphicsCostEstimator_pmoc.hpp>
#include <QObject>
#include <osg/GraphicsCostEstimator>

#include <osg/GraphicsCostEstimator_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLClampedLinearCostFunction1D: public QReflect_ClampedLinearCostFunction1D
{
Q_OBJECT
public:
QMLClampedLinearCostFunction1D(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLClampedLinearCostFunction1D)
#include <osg/GraphicsCostEstimator_pmoc.hpp>
#include <QObject>
#include <osg/GraphicsCostEstimator>

#include <osg/Referenced_pmoc.hpp>
#include <osg/GraphicsCostEstimator_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLGeometryCostEstimator: public QReflect_GeometryCostEstimator
{
Q_OBJECT
public:
QMLGeometryCostEstimator(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLGeometryCostEstimator)
#include <osg/GraphicsCostEstimator_pmoc.hpp>
#include <QObject>
#include <osg/GraphicsCostEstimator>

#include <osg/Referenced_pmoc.hpp>
#include <osg/GraphicsCostEstimator_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTextureCostEstimator: public QReflect_TextureCostEstimator
{
Q_OBJECT
public:
QMLTextureCostEstimator(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTextureCostEstimator)
#include <osg/GraphicsCostEstimator_pmoc.hpp>
#include <QObject>
#include <osg/GraphicsCostEstimator>

#include <osg/Referenced_pmoc.hpp>
#include <osg/GraphicsCostEstimator_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLProgramCostEstimator: public QReflect_ProgramCostEstimator
{
Q_OBJECT
public:
QMLProgramCostEstimator(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLProgramCostEstimator)

#endif //osg_GraphicsCostEstimator_customHPP


#ifndef osg_BufferIndexBinding_customHPP
#define  osg_BufferIndexBinding_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/BufferIndexBinding_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_BufferObject;
			} ;
#include <osg/BufferIndexBinding>

#include <osg/BufferObject>
#include <osg/BufferObject_pmoc.hpp>
#include <osg/StateAttribute_pmoc.hpp>
#include <osg/BufferIndexBinding_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLBufferIndexBinding: public QReflect_BufferIndexBinding
{
Q_OBJECT
public:
QMLBufferIndexBinding(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLBufferIndexBinding)
#include <osg/BufferIndexBinding_pmoc.hpp>
#include <QObject>
#include <osg/BufferIndexBinding>

#include <osg/BufferIndexBinding_pmoc.hpp>
#include <osg/BufferIndexBinding_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTransformFeedbackBufferBinding: public QReflect_TransformFeedbackBufferBinding
{
Q_OBJECT
public:
QMLTransformFeedbackBufferBinding(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTransformFeedbackBufferBinding)
#include <osg/BufferIndexBinding_pmoc.hpp>
#include <QObject>
#include <osg/BufferIndexBinding>

#include <osg/BufferIndexBinding_pmoc.hpp>
#include <osg/BufferIndexBinding_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLAtomicCounterBufferBinding: public QReflect_AtomicCounterBufferBinding
{
Q_OBJECT
public:
QMLAtomicCounterBufferBinding(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLAtomicCounterBufferBinding)
#include <osg/BufferIndexBinding_pmoc.hpp>
#include <QObject>
#include <osg/BufferIndexBinding>

#include <osg/BufferIndexBinding_pmoc.hpp>
#include <osg/BufferIndexBinding_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLUniformBufferBinding: public QReflect_UniformBufferBinding
{
Q_OBJECT
public:
QMLUniformBufferBinding(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLUniformBufferBinding)
#include <osg/BufferIndexBinding_pmoc.hpp>
#include <QObject>
#include <osg/BufferIndexBinding>

#include <osg/BufferIndexBinding_pmoc.hpp>
#include <osg/BufferIndexBinding_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLShaderStorageBufferBinding: public QReflect_ShaderStorageBufferBinding
{
Q_OBJECT
public:
QMLShaderStorageBufferBinding(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLShaderStorageBufferBinding)

#endif //osg_BufferIndexBinding_customHPP


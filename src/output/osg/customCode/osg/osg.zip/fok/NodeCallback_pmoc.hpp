#ifndef osg_NodeCallback_customHPP
#define  osg_NodeCallback_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_NodeCallback_customHPP


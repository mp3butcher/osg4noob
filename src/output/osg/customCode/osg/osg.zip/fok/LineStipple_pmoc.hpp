#ifndef osg_LineStipple_customHPP
#define  osg_LineStipple_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/LineStipple_pmoc.hpp>
#include <QObject>
#include <osg/LineStipple>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/LineStipple_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLLineStipple: public QReflect_LineStipple
{
Q_OBJECT
public:
QMLLineStipple(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLLineStipple)

#endif //osg_LineStipple_customHPP


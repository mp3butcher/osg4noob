#ifndef osg_CullSettings_customHPP
#define  osg_CullSettings_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/CullSettings_pmoc.hpp>
#include <QObject>
#include <osg/CullSettings>

#include <osg/CullSettings_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCullSettings: public QReflect_CullSettings
{
Q_OBJECT
public:
QMLCullSettings(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCullSettings)

#endif //osg_CullSettings_customHPP


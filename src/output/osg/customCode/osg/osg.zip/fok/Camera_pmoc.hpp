#ifndef osg_Camera_customHPP
#define  osg_Camera_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/Camera_pmoc.hpp>
#include <QObject>
#include <osg/Camera>

#include <osg/Camera_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCameraRenderOrderSortOp: public QReflect_CameraRenderOrderSortOp
{
Q_OBJECT
public:
QMLCameraRenderOrderSortOp(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCameraRenderOrderSortOp)
#include <osg/Camera_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Object;
			} ;
namespace osg{ 
class QReflect_DisplaySettings;
			} ;
namespace osg{ 
class QReflect_Matrixd;
			} ;
namespace osg{ 
class QReflect_Stats;
			} ;
namespace osg{ 
class QReflect_GraphicsContext;
			} ;
namespace osg{ 
struct QReflect_GraphicsOperation;
			} ;
namespace osg{ 
class QReflect_OperationThread;
			} ;
namespace osg{ 
class QReflect_View;
			} ;
#include <osg/Camera>

#include <osg/CullSettings_pmoc.hpp>
#include <osg/DisplaySettings>
#include <osg/DisplaySettings_pmoc.hpp>
#include <osg/GraphicsContext>
#include <osg/GraphicsContext_pmoc.hpp>
#include <osg/GraphicsThread>
#include <osg/GraphicsThread_pmoc.hpp>
#include <osg/Matrixd>
#include <osg/Matrixd_pmoc.hpp>
#include <osg/Object>
#include <osg/Object_pmoc.hpp>
#include <osg/OperationThread>
#include <osg/OperationThread_pmoc.hpp>
#include <osg/Stats>
#include <osg/Stats_pmoc.hpp>
#include <osg/Transform_pmoc.hpp>
#include <osg/Camera_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCamera: public QReflect_Camera
{
Q_OBJECT
public:
QMLCamera(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCamera)

#endif //osg_Camera_customHPP


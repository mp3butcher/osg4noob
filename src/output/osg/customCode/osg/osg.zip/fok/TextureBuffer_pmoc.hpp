#ifndef osg_TextureBuffer_customHPP
#define  osg_TextureBuffer_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/TextureBuffer_pmoc.hpp>
#include <QObject>
#include <osg/TextureBuffer>

#include <osg/Texture_pmoc.hpp>
#include <osg/TextureBuffer_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTextureBuffer: public QReflect_TextureBuffer
{
Q_OBJECT
public:
QMLTextureBuffer(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTextureBuffer)

#endif //osg_TextureBuffer_customHPP


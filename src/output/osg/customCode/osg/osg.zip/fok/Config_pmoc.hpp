#ifndef osg_Config_customHPP
#define  osg_Config_customHPP 1
#include "../../Export.h" 
//includes
#endif //osg_Config_customHPP


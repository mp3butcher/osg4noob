#ifndef osg_BufferTemplate_customHPP
#define  osg_BufferTemplate_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_BufferTemplate_customHPP


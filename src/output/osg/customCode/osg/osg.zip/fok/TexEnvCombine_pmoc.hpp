#ifndef osg_TexEnvCombine_customHPP
#define  osg_TexEnvCombine_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/TexEnvCombine_pmoc.hpp>
#include <QObject>
#include <osg/StateAttribute_pmoc.hpp>
#include <osg/TexEnvCombine>

#include <osg/TexEnvCombine_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexEnvCombine: public QReflect_TexEnvCombine
{
Q_OBJECT
public:
QMLTexEnvCombine(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexEnvCombine)

#endif //osg_TexEnvCombine_customHPP


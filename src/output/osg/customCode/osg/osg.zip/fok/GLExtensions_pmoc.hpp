#ifndef osg_GLExtensions_customHPP
#define  osg_GLExtensions_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/GLExtensions_pmoc.hpp>
#include <QObject>
#include <osg/GLExtensions>

#include <osg/Referenced_pmoc.hpp>
#include <osg/GLExtensions_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLGLExtensions: public QReflect_GLExtensions
{
Q_OBJECT
public:
QMLGLExtensions(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLGLExtensions)

#endif //osg_GLExtensions_customHPP


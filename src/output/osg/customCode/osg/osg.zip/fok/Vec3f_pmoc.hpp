#ifndef osg_Vec3f_customHPP
#define  osg_Vec3f_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Vec3f_pmoc.hpp>
#include <QObject>
#include <osg/Vec3f>

#include <osg/Vec3f_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLVec3f: public QReflect_Vec3f
{
Q_OBJECT
public:
QMLVec3f(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLVec3f)

#endif //osg_Vec3f_customHPP


#ifndef osg_CullFace_customHPP
#define  osg_CullFace_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/CullFace_pmoc.hpp>
#include <QObject>
#include <osg/CullFace>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/CullFace_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCullFace: public QReflect_CullFace
{
Q_OBJECT
public:
QMLCullFace(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCullFace)

#endif //osg_CullFace_customHPP


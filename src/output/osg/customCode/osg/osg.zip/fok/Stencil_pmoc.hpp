#ifndef osg_Stencil_customHPP
#define  osg_Stencil_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Stencil_pmoc.hpp>
#include <QObject>
#include <osg/StateAttribute_pmoc.hpp>
#include <osg/Stencil>

#include <osg/Stencil_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLStencil: public QReflect_Stencil
{
Q_OBJECT
public:
QMLStencil(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLStencil)

#endif //osg_Stencil_customHPP


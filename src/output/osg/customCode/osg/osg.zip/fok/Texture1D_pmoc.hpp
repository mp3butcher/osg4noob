#ifndef osg_Texture1D_customHPP
#define  osg_Texture1D_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Texture1D_pmoc.hpp>
#include <QObject>
#include <osg/Texture1D>

#include <osg/Texture_pmoc.hpp>
#include <osg/Texture1D_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexture1D: public QReflect_Texture1D
{
Q_OBJECT
public:
QMLTexture1D(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexture1D)

#endif //osg_Texture1D_customHPP


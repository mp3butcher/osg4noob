#ifndef osg_Plane_customHPP
#define  osg_Plane_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Plane_pmoc.hpp>
#include <QObject>
#include <osg/Plane>

#include <osg/Plane_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLPlane: public QReflect_Plane
{
Q_OBJECT
public:
QMLPlane(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLPlane)

#endif //osg_Plane_customHPP


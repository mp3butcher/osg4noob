#ifndef osg_ClipControl_customHPP
#define  osg_ClipControl_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/ClipControl_pmoc.hpp>
#include <QObject>
#include <osg/ClipControl>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/ClipControl_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLClipControl: public QReflect_ClipControl
{
Q_OBJECT
public:
QMLClipControl(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLClipControl)

#endif //osg_ClipControl_customHPP


#ifndef osg_Switch_customHPP
#define  osg_Switch_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/Switch_pmoc.hpp>
#include <QObject>
#include <osg/Group_pmoc.hpp>
#include <osg/Switch>

#include <osg/Switch_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLSwitch: public QReflect_Switch
{
Q_OBJECT
public:
QMLSwitch(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLSwitch)

#endif //osg_Switch_customHPP


#ifndef osg_BlendFunc_customHPP
#define  osg_BlendFunc_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/BlendFunc_pmoc.hpp>
#include <QObject>
#include <osg/BlendFunc>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/BlendFunc_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLBlendFunc: public QReflect_BlendFunc
{
Q_OBJECT
public:
QMLBlendFunc(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLBlendFunc)

#endif //osg_BlendFunc_customHPP


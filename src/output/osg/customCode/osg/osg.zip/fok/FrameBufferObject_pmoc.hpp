#ifndef osg_FrameBufferObject_customHPP
#define  osg_FrameBufferObject_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/FrameBufferObject_pmoc.hpp>
#include <QObject>
#include <osg/FrameBufferObject>

#include <osg/FrameBufferObject_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLFrameBufferAttachment: public QReflect_FrameBufferAttachment
{
Q_OBJECT
public:
QMLFrameBufferAttachment(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLFrameBufferAttachment)
#include <osg/FrameBufferObject_pmoc.hpp>
#include <QObject>
#include <osg/FrameBufferObject>

#include <osg/Object_pmoc.hpp>
#include <osg/FrameBufferObject_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLRenderBuffer: public QReflect_RenderBuffer
{
Q_OBJECT
public:
QMLRenderBuffer(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLRenderBuffer)
#include <osg/FrameBufferObject_pmoc.hpp>
#include <QObject>
#include <osg/FrameBufferObject>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/FrameBufferObject_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLFrameBufferObject: public QReflect_FrameBufferObject
{
Q_OBJECT
public:
QMLFrameBufferObject(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLFrameBufferObject)

#endif //osg_FrameBufferObject_customHPP


#ifndef osg_Types_customHPP
#define  osg_Types_customHPP 1
#include "../../Export.h" 
//includes
#endif //osg_Types_customHPP


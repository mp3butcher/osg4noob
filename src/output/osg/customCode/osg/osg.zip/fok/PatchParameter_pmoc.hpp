#ifndef osg_PatchParameter_customHPP
#define  osg_PatchParameter_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/PatchParameter_pmoc.hpp>
#include <QObject>
#include <osg/PatchParameter>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/PatchParameter_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLPatchParameter: public QReflect_PatchParameter
{
Q_OBJECT
public:
QMLPatchParameter(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLPatchParameter)

#endif //osg_PatchParameter_customHPP


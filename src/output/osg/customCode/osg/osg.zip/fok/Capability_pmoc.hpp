#ifndef osg_Capability_customHPP
#define  osg_Capability_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Capability_pmoc.hpp>
#include <QObject>
#include <osg/Capability>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/Capability_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCapability: public QReflect_Capability
{
Q_OBJECT
public:
QMLCapability(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCapability)
#include <osg/Capability_pmoc.hpp>
#include <QObject>
#include <osg/Capability>

#include <osg/Capability_pmoc.hpp>
#include <osg/Capability_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCapabilityi: public QReflect_Capabilityi
{
Q_OBJECT
public:
QMLCapabilityi(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCapabilityi)
#include <osg/Capability_pmoc.hpp>
#include <QObject>
#include <osg/Capability>

#include <osg/Capability_pmoc.hpp>
#include <osg/Capability_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLEnablei: public QReflect_Enablei
{
Q_OBJECT
public:
QMLEnablei(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLEnablei)
#include <osg/Capability_pmoc.hpp>
#include <QObject>
#include <osg/Capability>

#include <osg/Capability_pmoc.hpp>
#include <osg/Capability_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDisablei: public QReflect_Disablei
{
Q_OBJECT
public:
QMLDisablei(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDisablei)

#endif //osg_Capability_customHPP


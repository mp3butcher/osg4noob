#ifndef osg_TriangleIndexFunctor_customHPP
#define  osg_TriangleIndexFunctor_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_TriangleIndexFunctor_customHPP


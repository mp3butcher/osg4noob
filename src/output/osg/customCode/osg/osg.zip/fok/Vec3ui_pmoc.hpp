#ifndef osg_Vec3ui_customHPP
#define  osg_Vec3ui_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Vec3ui_pmoc.hpp>
#include <QObject>
#include <osg/Vec3ui>

#include <osg/Vec3ui_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLVec3ui: public QReflect_Vec3ui
{
Q_OBJECT
public:
QMLVec3ui(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLVec3ui)

#endif //osg_Vec3ui_customHPP


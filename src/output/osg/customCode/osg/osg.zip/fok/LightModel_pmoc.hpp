#ifndef osg_LightModel_customHPP
#define  osg_LightModel_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/LightModel_pmoc.hpp>
#include <QObject>
#include <osg/LightModel>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/LightModel_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLLightModel: public QReflect_LightModel
{
Q_OBJECT
public:
QMLLightModel(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLLightModel)

#endif //osg_LightModel_customHPP


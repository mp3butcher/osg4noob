#ifndef osg_CoordinateSystemNode_customHPP
#define  osg_CoordinateSystemNode_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/CoordinateSystemNode_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_EllipsoidModel;
			} ;
#include <osg/CoordinateSystemNode>
#include <osg/CoordinateSystemNode>

#include <osg/CoordinateSystemNode_pmoc.hpp>
#include <osg/Group_pmoc.hpp>
#include <osg/CoordinateSystemNode_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCoordinateSystemNode: public QReflect_CoordinateSystemNode
{
Q_OBJECT
public:
QMLCoordinateSystemNode(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCoordinateSystemNode)
#include <osg/CoordinateSystemNode_pmoc.hpp>
#include <QObject>
#include <osg/CoordinateSystemNode>

#include <osg/Object_pmoc.hpp>
#include <osg/CoordinateSystemNode_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLEllipsoidModel: public QReflect_EllipsoidModel
{
Q_OBJECT
public:
QMLEllipsoidModel(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLEllipsoidModel)

#endif //osg_CoordinateSystemNode_customHPP


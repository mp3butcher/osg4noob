#ifndef osg_BlendEquation_customHPP
#define  osg_BlendEquation_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/BlendEquation_pmoc.hpp>
#include <QObject>
#include <osg/BlendEquation>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/BlendEquation_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLBlendEquation: public QReflect_BlendEquation
{
Q_OBJECT
public:
QMLBlendEquation(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLBlendEquation)

#endif //osg_BlendEquation_customHPP


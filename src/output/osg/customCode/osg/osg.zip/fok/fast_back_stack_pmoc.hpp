#ifndef osg_fast_back_stack_customHPP
#define  osg_fast_back_stack_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_fast_back_stack_customHPP


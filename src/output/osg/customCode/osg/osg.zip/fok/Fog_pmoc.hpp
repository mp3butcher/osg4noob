#ifndef osg_Fog_customHPP
#define  osg_Fog_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Fog_pmoc.hpp>
#include <QObject>
#include <osg/Fog>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/Fog_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLFog: public QReflect_Fog
{
Q_OBJECT
public:
QMLFog(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLFog)

#endif //osg_Fog_customHPP


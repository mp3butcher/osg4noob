#ifndef osg_Vec4_customHPP
#define  osg_Vec4_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_Vec4_customHPP


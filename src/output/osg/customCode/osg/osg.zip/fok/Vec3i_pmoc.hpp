#ifndef osg_Vec3i_customHPP
#define  osg_Vec3i_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Vec3i_pmoc.hpp>
#include <QObject>
#include <osg/Vec3i>

#include <osg/Vec3i_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLVec3i: public QReflect_Vec3i
{
Q_OBJECT
public:
QMLVec3i(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLVec3i)

#endif //osg_Vec3i_customHPP


#ifndef osg_Shape_customHPP
#define  osg_Shape_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Shape_pmoc.hpp>
#include <QObject>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLShapeVisitor: public QReflect_ShapeVisitor
{
Q_OBJECT
public:
QMLShapeVisitor(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLShapeVisitor)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
#include <osg/Object_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLShape: public QReflect_Shape
{
Q_OBJECT
public:
QMLShape(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLShape)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
#include <osg/Plane_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLInfinitePlane: public QReflect_InfinitePlane
{
Q_OBJECT
public:
QMLInfinitePlane(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLInfinitePlane)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Quat;
			} ;
#include <osg/Quat>
#include <osg/Quat_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLHeightField: public QReflect_HeightField
{
Q_OBJECT
public:
QMLHeightField(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLHeightField)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Quat;
			} ;
#include <osg/Quat>
#include <osg/Quat_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCylinder: public QReflect_Cylinder
{
Q_OBJECT
public:
QMLCylinder(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCylinder)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLConstShapeVisitor: public QReflect_ConstShapeVisitor
{
Q_OBJECT
public:
QMLConstShapeVisitor(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLConstShapeVisitor)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Shape;
			} ;
#include <osg/Shape>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCompositeShape: public QReflect_CompositeShape
{
Q_OBJECT
public:
QMLCompositeShape(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCompositeShape)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Quat;
			} ;
#include <osg/Quat>
#include <osg/Quat_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLBox: public QReflect_Box
{
Q_OBJECT
public:
QMLBox(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLBox)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLSphere: public QReflect_Sphere
{
Q_OBJECT
public:
QMLSphere(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLSphere)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Quat;
			} ;
#include <osg/Quat>
#include <osg/Quat_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCone: public QReflect_Cone
{
Q_OBJECT
public:
QMLCone(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCone)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_IndexArray;
			} ;
#include <osg/Array>
#include <osg/Array_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTriangleMesh: public QReflect_TriangleMesh
{
Q_OBJECT
public:
QMLTriangleMesh(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTriangleMesh)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLConvexHull: public QReflect_ConvexHull
{
Q_OBJECT
public:
QMLConvexHull(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLConvexHull)
#include <osg/Shape_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Quat;
			} ;
#include <osg/Quat>
#include <osg/Quat_pmoc.hpp>
#include <osg/Shape>

#include <osg/Shape_pmoc.hpp>
#include <osg/Shape_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCapsule: public QReflect_Capsule
{
Q_OBJECT
public:
QMLCapsule(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCapsule)

#endif //osg_Shape_customHPP


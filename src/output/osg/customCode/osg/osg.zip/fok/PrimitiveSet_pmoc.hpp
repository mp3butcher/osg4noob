#ifndef osg_PrimitiveSet_customHPP
#define  osg_PrimitiveSet_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLPrimitiveIndexFunctor: public QReflect_PrimitiveIndexFunctor
{
Q_OBJECT
public:
QMLPrimitiveIndexFunctor(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLPrimitiveIndexFunctor)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLPrimitiveFunctor: public QReflect_PrimitiveFunctor
{
Q_OBJECT
public:
QMLPrimitiveFunctor(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLPrimitiveFunctor)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/BufferObject_pmoc.hpp>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLPrimitiveSet: public QReflect_PrimitiveSet
{
Q_OBJECT
public:
QMLPrimitiveSet(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLPrimitiveSet)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_ElementBufferObject;
			} ;
#include <osg/BufferObject>
#include <osg/BufferObject_pmoc.hpp>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDrawElements: public QReflect_DrawElements
{
Q_OBJECT
public:
QMLDrawElements(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDrawElements)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDrawArrayLengths: public QReflect_DrawArrayLengths
{
Q_OBJECT
public:
QMLDrawArrayLengths(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDrawArrayLengths)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDrawElementsUShort: public QReflect_DrawElementsUShort
{
Q_OBJECT
public:
QMLDrawElementsUShort(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDrawElementsUShort)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDrawElementsUByte: public QReflect_DrawElementsUByte
{
Q_OBJECT
public:
QMLDrawElementsUByte(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDrawElementsUByte)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDrawElementsUInt: public QReflect_DrawElementsUInt
{
Q_OBJECT
public:
QMLDrawElementsUInt(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDrawElementsUInt)
#include <osg/PrimitiveSet_pmoc.hpp>
#include <QObject>
#include <osg/PrimitiveSet>

#include <osg/PrimitiveSet_pmoc.hpp>
#include <osg/PrimitiveSet_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLDrawArrays: public QReflect_DrawArrays
{
Q_OBJECT
public:
QMLDrawArrays(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLDrawArrays)

#endif //osg_PrimitiveSet_customHPP


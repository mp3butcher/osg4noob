#ifndef osg_PointSprite_customHPP
#define  osg_PointSprite_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/PointSprite_pmoc.hpp>
#include <QObject>
#include <osg/PointSprite>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/PointSprite_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLPointSprite: public QReflect_PointSprite
{
Q_OBJECT
public:
QMLPointSprite(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLPointSprite)

#endif //osg_PointSprite_customHPP


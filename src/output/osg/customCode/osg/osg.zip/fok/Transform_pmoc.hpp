#ifndef osg_Transform_customHPP
#define  osg_Transform_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/Transform_pmoc.hpp>
#include <QObject>
#include <osg/Group_pmoc.hpp>
#include <osg/Transform>

#include <osg/Transform_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTransform: public QReflect_Transform
{
Q_OBJECT
public:
QMLTransform(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTransform)

#endif //osg_Transform_customHPP


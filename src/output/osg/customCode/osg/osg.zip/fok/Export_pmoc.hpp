#ifndef osg_Export_customHPP
#define  osg_Export_customHPP 1
#include "../../Export.h" 
//includes
#endif //osg_Export_customHPP


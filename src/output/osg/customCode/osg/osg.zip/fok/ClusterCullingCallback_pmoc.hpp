#ifndef osg_ClusterCullingCallback_customHPP
#define  osg_ClusterCullingCallback_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/ClusterCullingCallback_pmoc.hpp>
#include <QObject>
#include <osg/ClusterCullingCallback>

#include <osg/NodeCallback_pmoc.hpp>
#include <osg/ClusterCullingCallback_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLClusterCullingCallback: public QReflect_ClusterCullingCallback
{
Q_OBJECT
public:
QMLClusterCullingCallback(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLClusterCullingCallback)

#endif //osg_ClusterCullingCallback_customHPP


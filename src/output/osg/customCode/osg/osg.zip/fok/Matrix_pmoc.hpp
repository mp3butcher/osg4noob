#ifndef osg_Matrix_customHPP
#define  osg_Matrix_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_Matrix_customHPP


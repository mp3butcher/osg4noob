#ifndef osg_TriangleLinePointIndexFunctor_customHPP
#define  osg_TriangleLinePointIndexFunctor_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_TriangleLinePointIndexFunctor_customHPP


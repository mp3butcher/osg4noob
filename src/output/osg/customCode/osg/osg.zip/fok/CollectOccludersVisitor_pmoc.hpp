#ifndef osg_CollectOccludersVisitor_customHPP
#define  osg_CollectOccludersVisitor_customHPP 1
#include "../../Export.h" 
//includes

#include <osg/CollectOccludersVisitor_pmoc.hpp>
#include <QObject>
#include <osg/CollectOccludersVisitor>

#include <osg/CullStack_pmoc.hpp>
#include <osg/NodeVisitor_pmoc.hpp>
#include <osg/CollectOccludersVisitor_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCollectOccludersVisitor: public QReflect_CollectOccludersVisitor
{
Q_OBJECT
public:
QMLCollectOccludersVisitor(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCollectOccludersVisitor)

#endif //osg_CollectOccludersVisitor_customHPP


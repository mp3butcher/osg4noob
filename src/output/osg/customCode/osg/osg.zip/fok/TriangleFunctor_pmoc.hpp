#ifndef osg_TriangleFunctor_customHPP
#define  osg_TriangleFunctor_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_TriangleFunctor_customHPP


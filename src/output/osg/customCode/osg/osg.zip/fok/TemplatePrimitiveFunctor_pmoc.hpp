#ifndef osg_TemplatePrimitiveFunctor_customHPP
#define  osg_TemplatePrimitiveFunctor_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_TemplatePrimitiveFunctor_customHPP


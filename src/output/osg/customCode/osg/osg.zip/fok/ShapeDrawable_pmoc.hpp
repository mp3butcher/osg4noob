#ifndef osg_ShapeDrawable_customHPP
#define  osg_ShapeDrawable_customHPP 1
#include "../../Export.h" 
//includes


#include <osg/ShapeDrawable_pmoc.hpp>
#include <QObject>
#include <osg/Object_pmoc.hpp>
#include <osg/ShapeDrawable>

#include <osg/ShapeDrawable_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTessellationHints: public QReflect_TessellationHints
{
Q_OBJECT
public:
QMLTessellationHints(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTessellationHints)
#include <osg/ShapeDrawable_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_TessellationHints;
			} ;
#include <osg/Drawable_pmoc.hpp>
#include <osg/ShapeDrawable>
#include <osg/ShapeDrawable>

#include <osg/ShapeDrawable_pmoc.hpp>
#include <osg/ShapeDrawable_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLShapeDrawable: public QReflect_ShapeDrawable
{
Q_OBJECT
public:
QMLShapeDrawable(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLShapeDrawable)

#endif //osg_ShapeDrawable_customHPP


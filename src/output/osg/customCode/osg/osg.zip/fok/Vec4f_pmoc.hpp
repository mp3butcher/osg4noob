#ifndef osg_Vec4f_customHPP
#define  osg_Vec4f_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Vec4f_pmoc.hpp>
#include <QObject>
#include <osg/Vec4f>

#include <osg/Vec4f_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLVec4f: public QReflect_Vec4f
{
Q_OBJECT
public:
QMLVec4f(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLVec4f)

#endif //osg_Vec4f_customHPP


#ifndef osg_Matrixf_customHPP
#define  osg_Matrixf_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Matrixf_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_Quat;
			} ;
#include <osg/Matrixf>

#include <osg/Quat>
#include <osg/Quat_pmoc.hpp>
#include <osg/Matrixf_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLMatrixf: public QReflect_Matrixf
{
Q_OBJECT
public:
QMLMatrixf(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLMatrixf)
#include <osg/Matrixf_pmoc.hpp>
#include <QObject>
#include <osg/Matrixf>

#include <osg/Matrixf_pmoc.hpp>
#include <osg/Object_pmoc.hpp>
#include <osg/Matrixf_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLRefMatrixf: public QReflect_RefMatrixf
{
Q_OBJECT
public:
QMLRefMatrixf(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLRefMatrixf)

#endif //osg_Matrixf_customHPP


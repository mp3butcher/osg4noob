#ifndef osg_GLObjects_customHPP
#define  osg_GLObjects_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_GLObjects_customHPP


#ifndef osg_AlphaFunc_customHPP
#define  osg_AlphaFunc_customHPP 1
#include "../../Export.h"
//includes
#include <osg/AlphaFunc_pmoc.hpp>
#include <QObject>
#include <osg/AlphaFunc>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/AlphaFunc_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLAlphaFunc: public QReflect_AlphaFunc
{
Q_OBJECT
public:
QMLAlphaFunc(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();

};
class osgPMOC_EXPORTS newclass:public MetaQMLAlphaFunc{};
}
  Q_DECLARE_METATYPE(osg::QMLAlphaFunc)

#endif //osg_AlphaFunc_customHPP


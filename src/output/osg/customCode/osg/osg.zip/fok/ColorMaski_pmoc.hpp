#ifndef osg_ColorMaski_customHPP
#define  osg_ColorMaski_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/ColorMaski_pmoc.hpp>
#include <QObject>
#include <osg/ColorMask_pmoc.hpp>
#include <osg/ColorMaski>

#include <osg/ColorMaski_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLColorMaski: public QReflect_ColorMaski
{
Q_OBJECT
public:
QMLColorMaski(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLColorMaski)

#endif //osg_ColorMaski_customHPP


#ifndef osg_Vec4ui_customHPP
#define  osg_Vec4ui_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Vec4ui_pmoc.hpp>
#include <QObject>
#include <osg/Vec4ui>

#include <osg/Vec4ui_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLVec4ui: public QReflect_Vec4ui
{
Q_OBJECT
public:
QMLVec4ui(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLVec4ui)

#endif //osg_Vec4ui_customHPP


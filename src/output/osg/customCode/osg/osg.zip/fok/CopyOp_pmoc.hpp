#ifndef osg_CopyOp_customHPP
#define  osg_CopyOp_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/CopyOp_pmoc.hpp>
#include <QObject>
#include <osg/CopyOp>

#include <osg/CopyOp_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLCopyOp: public QReflect_CopyOp
{
Q_OBJECT
public:
QMLCopyOp(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLCopyOp)

#endif //osg_CopyOp_customHPP


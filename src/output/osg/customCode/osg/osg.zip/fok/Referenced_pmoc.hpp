#ifndef osg_Referenced_customHPP
#define  osg_Referenced_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Referenced_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_DeleteHandler;
			} ;
#include <osg/DeleteHandler>  
//no deffilename
#include <osg/DeleteHandler_pmoc.hpp>  
//no deffilename
#include <osg/Referenced>

#include <osg/Referenced_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLReferenced: public QReflect_Referenced
{
Q_OBJECT
public:
QMLReferenced(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLReferenced)

#endif //osg_Referenced_customHPP


#ifndef osg_ColorMask_customHPP
#define  osg_ColorMask_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/ColorMask_pmoc.hpp>
#include <QObject>
#include <osg/ColorMask>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/ColorMask_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLColorMask: public QReflect_ColorMask
{
Q_OBJECT
public:
QMLColorMask(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLColorMask)

#endif //osg_ColorMask_customHPP


#ifndef osg_FragmentProgram_customHPP
#define  osg_FragmentProgram_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/FragmentProgram_pmoc.hpp>
#include <QObject>
#include <osg/FragmentProgram>

#include <osg/StateAttribute_pmoc.hpp>
#include <osg/FragmentProgram_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLFragmentProgram: public QReflect_FragmentProgram
{
Q_OBJECT
public:
QMLFragmentProgram(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLFragmentProgram)

#endif //osg_FragmentProgram_customHPP


#ifndef osg_Vec4ub_customHPP
#define  osg_Vec4ub_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Vec4ub_pmoc.hpp>
#include <QObject>
#include <osg/Vec4ub>

#include <osg/Vec4ub_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLVec4ub: public QReflect_Vec4ub
{
Q_OBJECT
public:
QMLVec4ub(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLVec4ub)

#endif //osg_Vec4ub_customHPP


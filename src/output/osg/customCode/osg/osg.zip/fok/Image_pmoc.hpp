#ifndef osg_Image_customHPP
#define  osg_Image_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Image_pmoc.hpp>
#include <QObject>
namespace osg{ 
class QReflect_PixelBufferObject;
			} ;
#include <osg/BufferObject>
#include <osg/BufferObject_pmoc.hpp>
#include <osg/Image>

#include <osg/Image_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLImage: public QReflect_Image
{
Q_OBJECT
public:
QMLImage(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLImage)

#endif //osg_Image_customHPP


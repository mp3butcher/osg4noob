#ifndef osg_Shader_customHPP
#define  osg_Shader_customHPP 1
#include "../../Export.h"
//includes
#include <osg/Shader_pmoc.hpp>
#include <QObject>
#include <osg/Object_pmoc.hpp>
#include <osg/Shader>

#include <osg/Shader_pmoc.hpp>



#include <QUrl>
#include <Qsci/qsciscintilla.h>
#include <Qsci/qscilexercpp.h>
namespace osg
{
class osgPMOC_EXPORTS QMLShaderBinary: public QReflect_ShaderBinary
{
    Q_OBJECT


public:
    QMLShaderBinary(pmoc::Instance *i=0,QObject* parent=0);
    virtual QQuickItem * connect2View(QQuickItem*);
public slots:
    virtual void  updateModel();

};

}
Q_DECLARE_METATYPE(osg::QMLShaderBinary)
#include <osg/Shader_pmoc.hpp>
#include <QObject>
#include <osg/Object_pmoc.hpp>
#include <osg/Shader>

#include <osg/Shader_pmoc.hpp>
namespace osg
{
class osgPMOC_EXPORTS QMLShaderComponent: public QReflect_ShaderComponent
{
    Q_OBJECT
public:
    QMLShaderComponent(pmoc::Instance *i=0,QObject* parent=0);
    virtual QQuickItem * connect2View(QQuickItem*);
public slots:
    virtual void  updateModel();

};

}
Q_DECLARE_METATYPE(osg::QMLShaderComponent)
#include <osg/Shader_pmoc.hpp>
#include <QObject>
namespace osg
{
class QReflect_ShaderBinary;
} ;
#include <osg/Object_pmoc.hpp>
#include <osg/Shader>
#include <osg/Shader>

#include <osg/Shader_pmoc.hpp>
#include <osg/Shader_pmoc.hpp>
namespace osg
{
class osgPMOC_EXPORTS QMLShader: public QReflect_Shader
{
    Q_OBJECT
     Q_PROPERTY(int shaderType READ getshaderType WRITE setshaderType NOTIFY shaderTypeChanged)
    Q_PROPERTY(QStringList typeList READ typeList NOTIFY typeListChanged)
public:
    QStringList typeList()
    {
        return shaderTypeList;
    }

    int getshaderType()const;
    void setshaderType(int);
signals:
    void typeListChanged(QStringList&);
    void shaderTypeChanged(int);
protected:

    QStringList shaderTypeList;
    QsciScintilla* qsci;
    QsciLexerCPP *lex;
public slots:
    Q_INVOKABLE void setSourceFromFile(QUrl );
    void saveChange();
    //popEditor
    void popQscintilla();
public:
    QMLShader(pmoc::Instance *i=0,QObject* parent=0);
    virtual ~QMLShader();
    virtual QQuickItem * connect2View(QQuickItem*);
public slots:
    virtual void  updateModel();

};

}
Q_DECLARE_METATYPE(osg::QMLShader)

#endif //osg_Shader_customHPP


#ifndef osg_Vec3_customHPP
#define  osg_Vec3_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_Vec3_customHPP


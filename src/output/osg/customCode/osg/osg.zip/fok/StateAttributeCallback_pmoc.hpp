#ifndef osg_StateAttributeCallback_customHPP
#define  osg_StateAttributeCallback_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_StateAttributeCallback_customHPP


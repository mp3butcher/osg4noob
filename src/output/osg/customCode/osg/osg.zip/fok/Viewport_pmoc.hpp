#ifndef osg_Viewport_customHPP
#define  osg_Viewport_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Viewport_pmoc.hpp>
#include <QObject>
#include <osg/StateAttribute_pmoc.hpp>
#include <osg/Viewport>

#include <osg/Viewport_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLViewport: public QReflect_Viewport
{
Q_OBJECT
public:
QMLViewport(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLViewport)

#endif //osg_Viewport_customHPP


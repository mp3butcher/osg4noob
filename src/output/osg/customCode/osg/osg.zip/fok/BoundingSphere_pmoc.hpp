#ifndef osg_BoundingSphere_customHPP
#define  osg_BoundingSphere_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_BoundingSphere_customHPP


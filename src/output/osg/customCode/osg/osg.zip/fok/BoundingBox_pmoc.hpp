#ifndef osg_BoundingBox_customHPP
#define  osg_BoundingBox_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_BoundingBox_customHPP


#ifndef osg_GL2Extensions_customHPP
#define  osg_GL2Extensions_customHPP 1
#include "../../Export.h" 
//includes

#endif //osg_GL2Extensions_customHPP


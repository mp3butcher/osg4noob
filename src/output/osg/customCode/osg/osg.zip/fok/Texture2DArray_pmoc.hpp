#ifndef osg_Texture2DArray_customHPP
#define  osg_Texture2DArray_customHPP 1
#include "../../Export.h" 
//includes
#include <osg/Texture2DArray_pmoc.hpp>
#include <QObject>
#include <osg/Texture2DArray>

#include <osg/Texture_pmoc.hpp>
#include <osg/Texture2DArray_pmoc.hpp>
namespace osg{
class osgPMOC_EXPORTS QMLTexture2DArray: public QReflect_Texture2DArray
{
Q_OBJECT
public:
QMLTexture2DArray(pmoc::Instance *i=0,QObject* parent=0);
virtual QQuickItem * connect2View(QQuickItem*);
public slots:
 virtual void  updateModel();
 
}; 
 
} 
  Q_DECLARE_METATYPE(osg::QMLTexture2DArray)

#endif //osg_Texture2DArray_customHPP


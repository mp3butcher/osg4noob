/****************************************************************************
** Meta object code from reading C++ file 'BufferIndexBinding_pmoc.hpp'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "BufferIndexBinding_pmoc.hpp"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'BufferIndexBinding_pmoc.hpp' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_osg__QMLBufferIndexBinding_t {
    QByteArrayData data[3];
    char stringdata0[40];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLBufferIndexBinding_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLBufferIndexBinding_t qt_meta_stringdata_osg__QMLBufferIndexBinding = {
    {
QT_MOC_LITERAL(0, 0, 26), // "osg::QMLBufferIndexBinding"
QT_MOC_LITERAL(1, 27, 11), // "updateModel"
QT_MOC_LITERAL(2, 39, 0) // ""

    },
    "osg::QMLBufferIndexBinding\0updateModel\0"
    ""
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLBufferIndexBinding[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLBufferIndexBinding::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLBufferIndexBinding *_t = static_cast<QMLBufferIndexBinding *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLBufferIndexBinding::staticMetaObject = {
    { &QReflect_BufferIndexBinding::staticMetaObject, qt_meta_stringdata_osg__QMLBufferIndexBinding.data,
      qt_meta_data_osg__QMLBufferIndexBinding,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLBufferIndexBinding::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLBufferIndexBinding::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLBufferIndexBinding.stringdata0))
        return static_cast<void*>(const_cast< QMLBufferIndexBinding*>(this));
    return QReflect_BufferIndexBinding::qt_metacast(_clname);
}

int osg::QMLBufferIndexBinding::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_BufferIndexBinding::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLTransformFeedbackBufferBinding_t {
    QByteArrayData data[3];
    char stringdata0[52];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLTransformFeedbackBufferBinding_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLTransformFeedbackBufferBinding_t qt_meta_stringdata_osg__QMLTransformFeedbackBufferBinding = {
    {
QT_MOC_LITERAL(0, 0, 38), // "osg::QMLTransformFeedbackBuff..."
QT_MOC_LITERAL(1, 39, 11), // "updateModel"
QT_MOC_LITERAL(2, 51, 0) // ""

    },
    "osg::QMLTransformFeedbackBufferBinding\0"
    "updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLTransformFeedbackBufferBinding[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLTransformFeedbackBufferBinding::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLTransformFeedbackBufferBinding *_t = static_cast<QMLTransformFeedbackBufferBinding *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLTransformFeedbackBufferBinding::staticMetaObject = {
    { &QReflect_TransformFeedbackBufferBinding::staticMetaObject, qt_meta_stringdata_osg__QMLTransformFeedbackBufferBinding.data,
      qt_meta_data_osg__QMLTransformFeedbackBufferBinding,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLTransformFeedbackBufferBinding::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLTransformFeedbackBufferBinding::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLTransformFeedbackBufferBinding.stringdata0))
        return static_cast<void*>(const_cast< QMLTransformFeedbackBufferBinding*>(this));
    return QReflect_TransformFeedbackBufferBinding::qt_metacast(_clname);
}

int osg::QMLTransformFeedbackBufferBinding::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_TransformFeedbackBufferBinding::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLAtomicCounterBufferBinding_t {
    QByteArrayData data[3];
    char stringdata0[48];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLAtomicCounterBufferBinding_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLAtomicCounterBufferBinding_t qt_meta_stringdata_osg__QMLAtomicCounterBufferBinding = {
    {
QT_MOC_LITERAL(0, 0, 34), // "osg::QMLAtomicCounterBufferBi..."
QT_MOC_LITERAL(1, 35, 11), // "updateModel"
QT_MOC_LITERAL(2, 47, 0) // ""

    },
    "osg::QMLAtomicCounterBufferBinding\0"
    "updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLAtomicCounterBufferBinding[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLAtomicCounterBufferBinding::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLAtomicCounterBufferBinding *_t = static_cast<QMLAtomicCounterBufferBinding *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLAtomicCounterBufferBinding::staticMetaObject = {
    { &QReflect_AtomicCounterBufferBinding::staticMetaObject, qt_meta_stringdata_osg__QMLAtomicCounterBufferBinding.data,
      qt_meta_data_osg__QMLAtomicCounterBufferBinding,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLAtomicCounterBufferBinding::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLAtomicCounterBufferBinding::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLAtomicCounterBufferBinding.stringdata0))
        return static_cast<void*>(const_cast< QMLAtomicCounterBufferBinding*>(this));
    return QReflect_AtomicCounterBufferBinding::qt_metacast(_clname);
}

int osg::QMLAtomicCounterBufferBinding::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_AtomicCounterBufferBinding::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLUniformBufferBinding_t {
    QByteArrayData data[3];
    char stringdata0[42];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLUniformBufferBinding_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLUniformBufferBinding_t qt_meta_stringdata_osg__QMLUniformBufferBinding = {
    {
QT_MOC_LITERAL(0, 0, 28), // "osg::QMLUniformBufferBinding"
QT_MOC_LITERAL(1, 29, 11), // "updateModel"
QT_MOC_LITERAL(2, 41, 0) // ""

    },
    "osg::QMLUniformBufferBinding\0updateModel\0"
    ""
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLUniformBufferBinding[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLUniformBufferBinding::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLUniformBufferBinding *_t = static_cast<QMLUniformBufferBinding *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLUniformBufferBinding::staticMetaObject = {
    { &QReflect_UniformBufferBinding::staticMetaObject, qt_meta_stringdata_osg__QMLUniformBufferBinding.data,
      qt_meta_data_osg__QMLUniformBufferBinding,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLUniformBufferBinding::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLUniformBufferBinding::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLUniformBufferBinding.stringdata0))
        return static_cast<void*>(const_cast< QMLUniformBufferBinding*>(this));
    return QReflect_UniformBufferBinding::qt_metacast(_clname);
}

int osg::QMLUniformBufferBinding::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_UniformBufferBinding::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
struct qt_meta_stringdata_osg__QMLShaderStorageBufferBinding_t {
    QByteArrayData data[3];
    char stringdata0[48];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_osg__QMLShaderStorageBufferBinding_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_osg__QMLShaderStorageBufferBinding_t qt_meta_stringdata_osg__QMLShaderStorageBufferBinding = {
    {
QT_MOC_LITERAL(0, 0, 34), // "osg::QMLShaderStorageBufferBi..."
QT_MOC_LITERAL(1, 35, 11), // "updateModel"
QT_MOC_LITERAL(2, 47, 0) // ""

    },
    "osg::QMLShaderStorageBufferBinding\0"
    "updateModel\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_osg__QMLShaderStorageBufferBinding[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void osg::QMLShaderStorageBufferBinding::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QMLShaderStorageBufferBinding *_t = static_cast<QMLShaderStorageBufferBinding *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateModel(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject osg::QMLShaderStorageBufferBinding::staticMetaObject = {
    { &QReflect_ShaderStorageBufferBinding::staticMetaObject, qt_meta_stringdata_osg__QMLShaderStorageBufferBinding.data,
      qt_meta_data_osg__QMLShaderStorageBufferBinding,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *osg::QMLShaderStorageBufferBinding::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *osg::QMLShaderStorageBufferBinding::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_osg__QMLShaderStorageBufferBinding.stringdata0))
        return static_cast<void*>(const_cast< QMLShaderStorageBufferBinding*>(this));
    return QReflect_ShaderStorageBufferBinding::qt_metacast(_clname);
}

int osg::QMLShaderStorageBufferBinding::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QReflect_ShaderStorageBufferBinding::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}
QT_END_MOC_NAMESPACE

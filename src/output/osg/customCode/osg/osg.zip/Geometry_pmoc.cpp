#include <osg/Geometry>
//includes
#include <customCode/osg/Geometry_pmoc.hpp>
#include <customCode/osg/Array_pmoc.hpp>
#include <MetaQQuickLibraryRegistry.h>
#include <osgUtil/TangentSpaceGenerator>
#include <sstream>
using namespace std;
using namespace pmoc;

deprecated_osg::QMLGeometry::QMLGeometry(pmoc::Instance *i,QObject* parent):QReflect_Geometry(i,parent)
{
//custom initializations
}
QQuickItem* deprecated_osg::QMLGeometry::connect2View(QQuickItem*i)
{
    this->_view=QReflect_Geometry::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
    ///CustomiZE here



    return this->_view;
}

#include <customCode/osg/Geometry_pmoc.hpp>


void osg::QMLGeometry::generateTangentSpace(int normapmaptu,int coordindex)
{
    osg::ref_ptr<osgUtil::TangentSpaceGenerator >gen=new osgUtil::TangentSpaceGenerator;
    gen->generate(_model,normapmaptu);//normalmaptextureunit

    _model->setVertexAttribArray(coordindex,gen->getTangentArray (),osg::Array:: BIND_PER_VERTEX);

}

osg::QMLGeometry::QMLGeometry(pmoc::Instance *i,QObject* parent):QReflect_Geometry(i,parent)
{
//custom initializations
}
QQuickItem* osg::QMLGeometry::connect2View(QQuickItem*i)
{
    this->_view=QReflect_Geometry::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
    ///CustomiZE here
    updateModel();
   // connect(_view,SIGNAL(drawableselected(int)),this,SLOT(DrawableSelected(int)) );



    return this->_view;
}

void osg::QMLGeometry::updateModel()
{
osg::QReflect_Geometry::updateModel();
//reset listview
///orphans child
//if(_clickeddrawable)delete _clickeddrawable;
//_clickeddrawable=0;//->setParentItem(0);

    _qvertexAttribArray.resetListViewModel();
    int cpt=0;

    for(osg::Geometry::ArrayList::iterator it=_model->getTexCoordArrayList().begin(); it!=_model->getTexCoordArrayList().end(); it++)
    {
        osg:: Array* vaa=(*it);
        stringstream ss;
        ss<<cpt++;
        QString classname=QString((ss.str()).c_str());
        classname+=QString(vaa->className());
        StateAttribObject dra(classname,QString( vaa->getName().c_str()));
        _qvertexAttribArray.addStateAttrib(dra);
    }

    for(int i=0; i<100; i++)
    {
        osg:: Array *vaa=_model->getVertexAttribArray(i);
        vaa=_model->getVertexAttribArray(i);
        if(vaa)
        {
            stringstream ss;
            ss<<i;

            /*Instance inst=PMOCADDOBJECT(   *dr);
            QString classname=QString( inst.model->id().c_str());*/
            QString classname=QString((ss.str()).c_str());
            classname+=QString(vaa->className());
            StateAttribObject dra(classname,QString( vaa->getName().c_str()));
            _qvertexAttribArray.addStateAttrib(dra);
        }
    }
    emit vertexAttribArraysChanged(&_qvertexAttribArray );

}
///add attrib array to the first unsettted index
void osg::QMLGeometry::addVertexAttribArray(osg::QReflect_Array*par){

for(int i=0; i<100; i++)
    {
        osg:: Array *vaa=_model->getVertexAttribArray(i);
        vaa=_model->getVertexAttribArray(i);
        if(!vaa)
        {

           _model->setVertexAttribArray(i,par->_model);
           return;

        }
    }
}
///find in ordered collection and remove
void osg::QMLGeometry::pmoc_reverse_addVertexAttribArray(osg::QReflect_Array*par){
 for(int i=0; i<100; i++)
    {
        osg:: Array *vaa=_model->getVertexAttribArray(i);
        vaa=_model->getVertexAttribArray(i);
        if(vaa)
        {
           if(vaa==par->_model){
           _model->setVertexAttribArray(i,NULL);
           return;
           }
        }
    }
}

void osg::QMLGeometry::popSelectedVertexArray(int id){

int ix=0;      osg:: Array* vaa=*_model->getTexCoordArrayList().begin();
    for(osg::Geometry::ArrayList::iterator it=_model->getTexCoordArrayList().begin(); it!=_model->getTexCoordArrayList().end()&&ix!=id+1; it++)
    {
          vaa=(*it);

        ix++;
    }
    if(ix==id+1){

     pmoc::MetaQQuickClass*cl= PMOCGETMETACLASS("osg::Array");

     if(cl)///normal...no derived manipulable as we don't care a lot about vertices arrray human manipulation
     {

     Instance inst;
     inst.model=cl;
     inst.ptr=reinterpret_cast<void*>(vaa);
 cout<<typeid(*vaa).name()<<endl;
     cl->getGuiComponent((QQuickView*)_view->window(),inst,_view,"TexCoordArray");///TODO: Add ix as


     }
    }else{

int vertexattribindex;
 vaa=_model->getVertexAttribArray(0);

    for(int i=0; i<100&&ix!=id+1; i++)
    {
        vaa=_model->getVertexAttribArray(i);
        if(vaa){
        vertexattribindex=i;
        ix++;
        }
    }
  pmoc::MetaQQuickClass*cl= PMOCGETMETACLASS("osg::Array");

     if(cl)///normal...no derived manipulable as we don't care a lot about vertices arrray human manipulation
     {

     Instance inst;
     inst.model=cl;
     inst.ptr=reinterpret_cast<void*>(vaa);

     cl->getGuiComponent((QQuickView*)_view->window(),inst,_view,"VertexAttrib");///TODO: Add ix as


     }

}
}

#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_Geometry_pmoc.cpp"
#endif

#include <osg/Texture>
//includes
#include <MetaQQuickLibraryRegistry.h>
#include <customCode/osg/Texture_pmoc.hpp>
using namespace pmoc;
osg::QMLTexture::QMLTexture(pmoc::Instance *i,QObject* parent):QReflect_Texture(i,parent){
//custom initializations
}
QQuickItem* osg::QMLTexture::connect2View(QQuickItem*i){
	this->_view=QReflect_Texture::connect2View(i);
///connect this's signals/slot to its qml component////////////////////////////////////////////////////////////////
	///CustomiZE here



return this->_view;
}
void  osg::QMLTexture::updateModel(){
	  QReflect_Texture::updateModel();
///update this according to state of _model when it has been changed via pmoc/////////////////////////////////////////////
	///CustomiZE here


}
#ifndef AUTOMOCCPP
#define AUTOMOCCPP 1
#include "moc_Texture_pmoc.cpp"
#endif


